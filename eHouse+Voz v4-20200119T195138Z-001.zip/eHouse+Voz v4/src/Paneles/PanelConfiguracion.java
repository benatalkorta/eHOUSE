package Paneles;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.MouseAdapter;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;

import Componentes.TablaDispositivos;
import Controladores.ControladorConfiguracion;
import Objetos.Dispositivo;
import Objetos.Habitacion;
import Objetos.Piso;
import Objetos.Usuario;
import Principal.Principal;
import Renderers.RendererHabitaciones;

public class PanelConfiguracion extends JPanel {

	private static final long serialVersionUID = 1L;
	String usuario;
	Principal ventana;
	JButton bQuitarPiso, bA�adirPiso;
	JButton bA�adirHabita, bQuitarHabita;
	JComboBox<Piso> cbxpisos;
	JList<Habitacion> listaHabitaciones;
	ControladorConfiguracion controlador;
	JScrollPane panelListaHabitaciones;
	JLabel lUsuario;
	TablaDispositivos tablaDispositivos;
	JSplitPane spanel;

	public PanelConfiguracion(Principal ventana, String usuario) {
		super(new BorderLayout());
		this.usuario = usuario;
		this.ventana = ventana;
		controlador = new ControladorConfiguracion(this);
		this.setBackground(Color.WHITE);
		this.setLayout(new BorderLayout());
		this.add(crealToolBar(), BorderLayout.NORTH);
		this.add(crealPanelPrincipal(), BorderLayout.CENTER);
	}

	private Component crealToolBar() {
		JToolBar barra = new JToolBar();
		barra.setFloatable(false);
		barra.add(crearBotonCrearUsuario());
		barra.add(Box.createHorizontalGlue());
		barra.add(crearLogo());
		barra.add(Box.createHorizontalGlue());
		barra.add(crearLabelUsuario(usuario));
		barra.add(crearBotonSalir());
		barra.setBackground(Color.WHITE);
		return barra;
	}

	private Component crearBotonCrearUsuario() {
		JButton bCrearUsuario = new JButton(new ImageIcon("img/bCrearUsuario.png"));
		bCrearUsuario.setToolTipText("Crear nuevo usuario");
		bCrearUsuario.setBorderPainted(false);
		bCrearUsuario.setFocusPainted(false);
		bCrearUsuario.setContentAreaFilled(false);
		bCrearUsuario.setActionCommand("crear_usuario");
		bCrearUsuario.addActionListener(controlador);
		return bCrearUsuario;
	}

	private Component crealPanelPrincipal() {
		JSplitPane panelPrincipal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, crearPanelIzda(), crearPanelDcha());
		panelPrincipal.setBackground(Color.WHITE);
		panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		panelPrincipal.setDividerLocation(220);
		return panelPrincipal;
	}

	private Component crearPanelDcha() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.add(crearToolBarDispositivos(), BorderLayout.NORTH);
		panel.add(crearPanelDispositivos(), BorderLayout.CENTER);
		panel.setBackground(Color.WHITE);
		return panel;
	}

	private Component crearToolBarDispositivos() {
		JToolBar barra = new JToolBar();
		barra.setFloatable(false);
		barra.add(crearBotonA�adirDisp());
		barra.add(crearBotonQuitarDisp());
		barra.setBackground(Color.WHITE);
		return barra;
	}

	private JButton crearBotonQuitarDisp() {
		JButton bQuitarDisp = crearBoton("Quitar Dispositivo", "remove_dispositivo", "img/del.png");
		return bQuitarDisp;
	}

	private JButton crearBotonA�adirDisp() {
		JButton bA�adirDisp = crearBoton("A�adir Dispositivo", "add_dispositivo", "img/add.png");
		return bA�adirDisp;
	}

	private Component crearPanelDispositivos() {
		JScrollPane panel = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);// panelArriba
		panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLoweredBevelBorder(),
				"Lista de dispositivos", 0, 0, new Font("Calibri", Font.ITALIC, 20), Color.BLUE));

		PanelDispositivo panelDispositivo = new PanelDispositivo(ventana, null, false);// panelAbajo
		spanel = new JSplitPane(JSplitPane.VERTICAL_SPLIT, panel, panelDispositivo);
		Habitacion habitacion = listaHabitaciones.getSelectedValue();
		tablaDispositivos = new TablaDispositivos(habitacion);
		tablaDispositivos.addMouseListener(new MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				int fila = tablaDispositivos.getSelectedRow();
				Habitacion h = listaHabitaciones.getSelectedValue();
				Dispositivo dispositivo = h.getDispositivos().get(fila);
				PanelDispositivo panelDispositivo = new PanelDispositivo(ventana, dispositivo, true);
				spanel.setBottomComponent(panelDispositivo);
				spanel.setDividerLocation(300);
			}
		});
		panel.setViewportView(tablaDispositivos);
		panel.getViewport().setBackground(Color.WHITE);
		panel.setBackground(Color.WHITE);
		spanel.setDividerLocation(300);
		spanel.setBackground(Color.WHITE);
		spanel.setBorder(null);
		return spanel;
	}

	private Component crearPanelIzda() {
		JPanel panel = new JPanel(new BorderLayout(10, 10));
		panel.setBackground(Color.WHITE);
		panel.add(crearPanelArriba(), BorderLayout.NORTH);
		panel.add(crearPanelListaHabitaciones(), BorderLayout.CENTER);
		return panel;
	}

	private Component crearPanelArriba() {
		JPanel panel = new JPanel(new BorderLayout(10, 10));
		panel.setBackground(Color.WHITE);
		panel.add(crearPanelPisos(), BorderLayout.NORTH);
		panel.add(crearPanelEditarHabitaciones(), BorderLayout.CENTER);
		return panel;
	}

	private Component crearPanelEditarHabitaciones() {
		JPanel panel = new JPanel(new BorderLayout(10, 10));
		panel.setBorder(BorderFactory.createLineBorder(Color.MAGENTA));
		panel.setBackground(Color.WHITE);
		panel.add(crearPanelBotones2(), BorderLayout.EAST);
		panel.add(crearLabelHabitas(), BorderLayout.CENTER);
		return panel;
	}

	private Component crearLabelHabitas() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.white);
		JLabel label = new JLabel("Habitaciones");
		label.setFont(new Font("Agency FB", Font.BOLD, 20));
		panel.add(label);
		return panel;
	}

	private Component crearPanelBotones2() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(Color.WHITE);
		bA�adirHabita = crearBoton("A�adir habitaci�n", "add_habitacion", "img/add.png");
		bQuitarHabita = crearBoton("Eliminar habitaci�n", "remove_habitacion", "img/del.png");
		panel.add(bA�adirHabita, BorderLayout.WEST);
		panel.add(bQuitarHabita, BorderLayout.EAST);
		return panel;
	}

	private Component crearPanelListaHabitaciones() {
		panelListaHabitaciones = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		RendererHabitaciones renderer = new RendererHabitaciones();
		listaHabitaciones = new JList<>();
		try {
			listaHabitaciones.setModel(ventana.getCasa().getElementAt(0));
		} catch (IllegalArgumentException e) {

		}
		listaHabitaciones.setCellRenderer(renderer);
		listaHabitaciones.setSelectedIndex(0);
		listaHabitaciones.addListSelectionListener(controlador);
		panelListaHabitaciones.setViewportView(listaHabitaciones);
		return panelListaHabitaciones;
	}

	private Component crearPanelPisos() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(Color.WHITE);
		cbxpisos = new JComboBox<>(ventana.getCasa().getComboBoxModelo());
		cbxpisos.addItemListener(controlador);
		panel.add(cbxpisos, BorderLayout.CENTER);
		panel.add(crearPanelBotones1(), BorderLayout.EAST);
		return panel;
	}

	private Component crearPanelBotones1() {
		JPanel panel = new JPanel(new BorderLayout(0, 0));
		panel.setBackground(Color.WHITE);
		bA�adirPiso = crearBoton("A�adir piso", "add_piso", "img/add.png");
		bQuitarPiso = crearBoton("Eliminar piso", "remove_piso", "img/del.png");
		panel.add(bA�adirPiso, BorderLayout.WEST);
		panel.add(bQuitarPiso, BorderLayout.EAST);
		return panel;
	}

	private JButton crearBoton(String toolTipText, String actionCommand, String imagen) {
		JButton boton = new JButton(new ImageIcon(imagen));
		boton.setToolTipText(toolTipText);
		boton.setBorderPainted(false);
		boton.setFocusPainted(false);
		boton.setContentAreaFilled(false);
		boton.setActionCommand(actionCommand);
		boton.addActionListener(controlador);

		return boton;
	}

	public JLabel crearLabelUsuario(String usuario) {
		lUsuario = new JLabel(usuario);
		lUsuario.setFont(new Font("Agency FB", Font.BOLD, 40));
		return lUsuario;
	}

	private JLabel crearLogo() {
		JLabel labelLogo = new JLabel(new ImageIcon("img/logoPeque�o.png"));
		return labelLogo;
	}

	public void cambiarUsuario(Usuario u) {
		lUsuario.setText(u.getNombre());
		ventana.getGestorUsuarios().setUsuarioLogeado(u);
	}

	private Component crearBotonSalir() {
		JButton bSalir = new JButton(new ImageIcon("img/bsalir.png"));
		bSalir.setToolTipText("Ir a pantalla principal");
		bSalir.setBorderPainted(false);
		bSalir.setFocusPainted(false);
		bSalir.setContentAreaFilled(false);
		bSalir.setActionCommand("salir");
		bSalir.addActionListener(controlador);
		return bSalir;
	}

	public JComboBox<Piso> getCbxpisos() {
		return cbxpisos;
	}

	public Principal getVentana() {
		return ventana;
	}

	public JList<Habitacion> getListaHabitaciones() {
		return listaHabitaciones;
	}

	public JButton getbQuitarPiso() {
		return bQuitarPiso;
	}

	public JButton getbA�adirPiso() {
		return bA�adirPiso;
	}

	public JButton getbA�adirHabita() {
		return bA�adirHabita;
	}

	public JButton getbQuitarHabita() {
		return bQuitarHabita;
	}

	public JScrollPane getPanelListaHabitaciones() {
		return panelListaHabitaciones;
	}

	public JLabel getlUsuario() {
		return lUsuario;
	}

	public TablaDispositivos getTablaDispositivos() {
		return tablaDispositivos;
	}

	public JSplitPane getSpanel() {
		return spanel;
	}

}
