package voz;

import javax.speech.*;
import javax.speech.synthesis.*;
import java.util.*;

public class Lee implements Runnable{

	String texto;
	
	public Lee(String texto) {
		this.texto = texto;
	}

	@Override
	public void run() {
		try {

			String say = texto;

			SynthesizerModeDesc required = new SynthesizerModeDesc();
			required.setLocale(Locale.ROOT);
			
			Voice voice = new Voice();
			required.addVoice(voice);

			Synthesizer synth = Central.createSynthesizer(null);
			
			synth.allocate();
			synth.resume();

			synth.speakPlainText(say, null);

			synth.waitEngineState(Synthesizer.QUEUE_EMPTY);
			synth.deallocate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}