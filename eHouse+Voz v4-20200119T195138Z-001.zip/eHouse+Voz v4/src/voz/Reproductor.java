package voz;

import java.io.*;
import javax.sound.sampled.*;

public class Reproductor {
	
	Clip clip;

	public void reproducir(String nombre, boolean opcion) {
		
		if(!opcion) {
			clip.stop();
		} else {

		File archivo = new File(nombre);
		try {
			clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(archivo));
			clip.start();
		} catch (Exception e) {
			
		}
	  }
	}
}
