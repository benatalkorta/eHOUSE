package Dialogos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import Objetos.DispositivoProgramable;
import Objetos.Programa;

public class DialogoAddPrograma extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1L;
	JTextField txNombre;
	JButton bOK, bCancel;
	Programa programa;
	DispositivoProgramable dispositivo;

	public DialogoAddPrograma(DispositivoProgramable dispositivo, JFrame ventana) {
		super(ventana, "A�adir programa", true);
		programa = null;
		this.dispositivo = dispositivo;
		this.setSize(350, 300);
		this.setLocationRelativeTo(ventana);
		this.setContentPane(crearPanelVentana());
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	private Container crearPanelVentana() {
		JPanel panel = new JPanel(new BorderLayout(0, 10));
		panel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
		panel.add(crearPanelTitulo(), BorderLayout.NORTH);
		panel.add(crearPanelDatos(), BorderLayout.CENTER);
		panel.add(crearPanelBotones(), BorderLayout.SOUTH);
		panel.setBackground(Color.WHITE);
		return panel;
	}

	private Component crearPanelTitulo() {
		JPanel panel = new JPanel(new BorderLayout(10, 10));
		panel.setBackground(Color.WHITE);

		JLabel labelTitulo = new JLabel("A�adir programa");
		labelTitulo.setFont(new Font("Agency FB", Font.BOLD, 25));

		panel.add(labelTitulo, BorderLayout.CENTER);

		JLabel labelLogo = new JLabel(new ImageIcon("img/logoPeque�o.png"));

		panel.add(labelLogo, BorderLayout.EAST);

		return panel;
	}

	private Container crearPanelDatos() {
		JPanel panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
		panel.setBackground(Color.WHITE);
		panel.add(crearPanelNombre());
		return panel;
	}

	private JPanel crearPanelNombre() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);

		txNombre = new JTextField(20);
		panel.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Nombre"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		panel.add(txNombre);
		return panel;

	}

	private Component crearPanelBotones() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);

		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 0));
		panel.setAlignmentX(0.f);
		bOK = new JButton("  Ok  ");
		bOK.setActionCommand("ok");
		bOK.addActionListener(this);
		bCancel = new JButton("Cancel");
		bCancel.addActionListener(this);

		panel.add(bOK);
		panel.add(bCancel);
		return panel;
	}

	public Programa getPrograma() {
		return programa;
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		if (evt.getActionCommand().equals("ok")) {
			try {
				String nombre = txNombre.getText();
				programa = new Programa(dispositivo.getListaProgramas().size()+1, nombre);
				this.dispose();
			} catch (NullPointerException e) {
				JOptionPane.showMessageDialog(this, "No dejes el nombre vacio", "ERROR!!", JOptionPane.ERROR_MESSAGE);
			}
		} else {
			this.dispose();
		}
	}
}