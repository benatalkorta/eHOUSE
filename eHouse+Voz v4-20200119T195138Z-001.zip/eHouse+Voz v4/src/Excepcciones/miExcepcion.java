package Excepcciones;

public class miExcepcion extends Exception {

	private static final long serialVersionUID = 1L;

	public miExcepcion(String msg) {
		super(msg);
	}

}
