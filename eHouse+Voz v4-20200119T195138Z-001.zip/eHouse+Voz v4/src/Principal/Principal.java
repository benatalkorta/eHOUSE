package Principal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.Timer;

import Gestores.GestorUsuarios;
import Objetos.Casa;
import Paneles.PanelConfiguracion;
import Paneles.PanelConsumo;
import Paneles.PanelNormal;
import Paneles.PanelPrincipal;

public class Principal extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	PanelPrincipal panelPrincipal;
	Casa casa;
	GestorUsuarios gestorUsuarios;
	Timer temporizadorConsumo;
	final int PERIODO_DIA = 86400000;// milisegundos en un dia
	final String NOMBRE_FICHERO = "files/datosConsumoDisp.txt";
	List<Double> listaConsumoPrimeraSemana, listaConsumoSegundaSemana, listaTmp;

	public Principal() {
		super("eHOUSE");
		temporizadorConsumo = new Timer(PERIODO_DIA, this);
		temporizadorConsumo.start();
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setSize(600, 600);
		this.setLocation(600, 600);
		this.setUndecorated(true);
		this.setResizable(false);
		casa = leerCasaDeFichero();
//		casa = new Casa();
//		casa.inicializar();
		if (casa == null) {
			System.exit(0);
		}
		gestorUsuarios = new GestorUsuarios();
		gestorUsuarios.leerUsuariosDesdeFichero();
//		gestorUsuarios.inicializar();
//		gestorUsuarios.escribirUsuariosEnFichero();
		listaConsumoPrimeraSemana = new ArrayList<>();
		listaConsumoSegundaSemana = new ArrayList<>();
		listaTmp = new ArrayList<>();
		panelPrincipal = new PanelPrincipal(this);
		this.setContentPane(panelPrincipal);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	public void entrarModoConfiguracion(String usuario) {
		PanelConfiguracion panelPrivilegiado = new PanelConfiguracion(this, usuario);
		this.setContentPane(panelPrivilegiado);
		this.repaint();
		this.revalidate();
	}

	public Casa leerCasaDeFichero() {
		Casa casa;
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("files/" + Casa.FICHERO_CASA))) {

			while ((casa = (Casa) in.readObject()) != null) {
				return casa;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (EOFException e) {

		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void entrarModoNormal() {
		PanelNormal panelNormal = new PanelNormal(this);
		this.setContentPane(panelNormal);
		this.repaint();
		this.revalidate();
	}

	public void visualizarPanelConsumo() {
		PanelConsumo pConsumo = new PanelConsumo(this);
		this.setContentPane(pConsumo);
		this.repaint();
		this.revalidate();
	}

	public void entrarModoPrincipal() {
		this.setContentPane(panelPrincipal);
		this.setJMenuBar(null);
		this.repaint();
		this.revalidate();
	}

	public static void main(String[] args) {
		Principal ejercicio = new Principal();
	}

	public Casa getCasa() {
		return casa;
	}

	public GestorUsuarios getGestorUsuarios() {
		return gestorUsuarios;
	}

	public void guardarListasEnFichero() {
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(NOMBRE_FICHERO))) {
			for (Double d : listaConsumoPrimeraSemana) {
				bw.write(String.valueOf(d) + "$");
			}
			bw.write("\n");
			for (Double d : listaConsumoSegundaSemana) {
				bw.write(String.valueOf(d) + "$");
			}
			bw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (listaTmp.size() < 7) {
			listaTmp.add(casa.consumoTotalMomentaneo());
		} else {
			listaConsumoPrimeraSemana = listaConsumoSegundaSemana;
			listaConsumoSegundaSemana = listaTmp;
			guardarListasEnFichero();
			listaTmp = new ArrayList<>();
			listaTmp.add(casa.consumoTotalMomentaneo());
		}
		temporizadorConsumo.stop();
		temporizadorConsumo = new Timer(PERIODO_DIA, this);
		temporizadorConsumo.start();

	}

}
