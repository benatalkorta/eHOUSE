package Modelos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import Objetos.Programa;

public class ModeloTablaProgramas extends AbstractTableModel implements Serializable{

	private static final long serialVersionUID = 1L;

	final static String[] NOMBRE_COLUMNAS = { "Id", "Nombre", "Estado" };
	final static Class<?>[] TIPO_COLUMNAS = new Class<?>[] { Integer.class, String.class, Boolean.class };
	List<Programa> programas;

	public ModeloTablaProgramas() {
		programas = new ArrayList<>();
	}

	public void add(Programa p) {
		programas.add(p);
		this.fireTableDataChanged();
	}

	public void remove(Programa p) {
		programas.remove(p);
		this.fireTableDataChanged();
	}

	@Override
	public String getColumnName(int column) {
		return NOMBRE_COLUMNAS[column];
	}

	@Override
	public Class<?> getColumnClass(int column) {
		return TIPO_COLUMNAS[column];
	}

	@Override
	public void setValueAt(Object aValue, int fila, int columna) {
		Programa p = programas.get(fila);
		if (columna == 2)
			p.power();
	}

	@Override
	public boolean isCellEditable(int row, int col) {
		return col == 2;
	}

	@Override
	public int getColumnCount() {
		return NOMBRE_COLUMNAS.length;
	}

	@Override
	public int getRowCount() {
		return programas.size();
	}

	@Override
	public Object getValueAt(int fila, int columna) {
		Programa p = programas.get(fila);
		return p.getFieldAt(columna);
	}

}
