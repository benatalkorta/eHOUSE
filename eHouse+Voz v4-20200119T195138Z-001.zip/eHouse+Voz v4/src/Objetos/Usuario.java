package Objetos;

import java.io.Serializable;

public class Usuario implements Serializable {
	private static final long serialVersionUID = -8008965050735177061L;
	String nombre;
	String contrasenia;
	
	public Usuario(String nombre, String contrasenia) {
		this.nombre = nombre;
		this.contrasenia = contrasenia;
	}
	public String getNombre() {
		return nombre;
	}
	public String getContrasenia() {
		return contrasenia;
	}
	@Override
	public String toString() {
		return nombre;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null) return false;
		if (!(obj instanceof Usuario)) return false;
		Usuario usuario = (Usuario) obj;
		if (!this.nombre.equals(usuario.nombre)) return false;
		if (!this.contrasenia.equals(usuario.contrasenia)) return false;		
		return true;
	}
	@Override
	public int hashCode() {
		
		return nombre.hashCode()+contrasenia.hashCode();
	}
	
}
