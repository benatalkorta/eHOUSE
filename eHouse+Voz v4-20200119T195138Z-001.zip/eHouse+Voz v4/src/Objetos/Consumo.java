package Objetos;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;

public class Consumo implements Serializable{

	private static final long serialVersionUID = 1L;
	private static final String FICHERO_CONSUMO = "consumo.txt";
	private static final String SEPARADOR = "[$]";
	double temperaturaAgua;
	int temperaturaDeseada;
	boolean estadoCaldera;
	double energiaConsumiendose;
	double temperaturaCasa;
	double temperaturaExterior;

	public Consumo() {
		inicializarDesdeFichero();
		inicializarEnergiaConsumiendose();
		temperaturaDeseada = 20;
		estadoCaldera = false;
	}

	private void inicializarEnergiaConsumiendose() {
		energiaConsumiendose = 3000;
	}

	private void inicializarDesdeFichero() {
		try (BufferedReader in = new BufferedReader(new FileReader("files/" + FICHERO_CONSUMO))) {

			String linea;
			while ((linea = in.readLine()) != null) {
				String[] valores = linea.split(SEPARADOR);
				temperaturaAgua = Double.valueOf(valores[0]);
				temperaturaCasa = Double.valueOf(valores[1]);
				temperaturaExterior = Double.valueOf(valores[2]);
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public double getTemperaturaAgua() {
		return temperaturaAgua;
	}

	public void setTemperaturaAgua(double temperaturaAgua) {
		this.temperaturaAgua = temperaturaAgua;
	}

	public double getTemperaturaDeseada() {
		return temperaturaDeseada;
	}

	public void setTemperaturaDeseada(int temperaturaDeseada) {
		this.temperaturaDeseada = temperaturaDeseada;
	}

	public boolean isEstadoCaldera() {
		return estadoCaldera;
	}

	public void setEstadoCaldera(boolean estadoCaldera) {
		this.estadoCaldera = estadoCaldera;
	}

	public double getEnergiaConsumiendose() {
		return energiaConsumiendose;
	}

	public void setEnergiaConsumiendose(double energiaConsumiendose) {
		this.energiaConsumiendose = energiaConsumiendose;
	}

	public double getTemperaturaCasa() {
		return temperaturaCasa;
	}

	public void setTemperaturaCasa(double temperaturaCasa) {
		this.temperaturaCasa = temperaturaCasa;
	}

	public double getTemperaturaExterior() {
		return temperaturaExterior;
	}

	public void setTemperaturaExterior(double temperaturaExterior) {
		this.temperaturaExterior = temperaturaExterior;
	}

}
