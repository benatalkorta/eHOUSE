package Dialogos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Objetos.Usuario;

public class DialogoIniciarSesion extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1L;
	Usuario usuario = null;
	JTextField txUsuario;
	JPasswordField txContrasenia;
	JButton bOK, bCancel;
	Dimension dimensionBoton;

	public DialogoIniciarSesion(JFrame ventana) {
		super(ventana, "Modo Configuracion", true);
		this.setSize(350, 300);
		this.setLocationRelativeTo(ventana);
		this.setContentPane(crearPanelVentana());
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}

	private Container crearPanelVentana() {
		JPanel panel = new JPanel(new BorderLayout(0, 10));
		panel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

		panel.add(crearPanelDatos(), BorderLayout.CENTER);
		panel.add(crearPanelBotones(), BorderLayout.SOUTH);
		panel.add(crearPanelTitulo(), BorderLayout.NORTH);
		panel.setBackground(Color.WHITE);
		return panel;
	}

	private Component crearPanelTitulo() {
		JPanel panel = new JPanel(new BorderLayout(10, 10));
		panel.setBackground(Color.WHITE);

		JLabel labelTitulo = new JLabel("Iniciar Sesion");
		labelTitulo.setFont(new Font("Agency FB", Font.BOLD, 25));

		panel.add(labelTitulo, BorderLayout.CENTER);

		JLabel labelLogo = new JLabel(new ImageIcon("img/logoPeque�o.png"));

		panel.add(labelLogo, BorderLayout.EAST);

		return panel;
	}

	private Component crearPanelDatos() {
		JPanel panel = new JPanel(new GridLayout(2, 1, 0, 10));
		panel.setBackground(Color.WHITE);

		panel.add(crearPanelUsuario());
		panel.add(crearPanelContrasenia());

		return panel;
	}

	private JPanel crearPanelUsuario() {
		JPanel panelUsuario = new JPanel();
		panelUsuario.setBackground(Color.WHITE);

		txUsuario = new JTextField(20);
		panelUsuario.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Usuario"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		panelUsuario.add(txUsuario);
		return panelUsuario;

	}

	private JPanel crearPanelContrasenia() {
		JPanel panelContrasenia = new JPanel();
		panelContrasenia.setBackground(Color.WHITE);

		txContrasenia = new JPasswordField(20);
		panelContrasenia.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Contrase�a"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));

		panelContrasenia.add(txContrasenia);

		return panelContrasenia;
	}

	private Component crearPanelBotones() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);

		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 0));
		panel.setAlignmentX(0.f);
		bOK = new JButton("  Ok  ");
		bOK.addActionListener(this);
		bOK.setPreferredSize(dimensionBoton);
		bOK.setMinimumSize(dimensionBoton);
		bOK.setMaximumSize(dimensionBoton);
		bCancel = new JButton("Cancel");
		bCancel.addActionListener(this);
		bCancel.setPreferredSize(dimensionBoton);
		bCancel.setMinimumSize(dimensionBoton);
		bCancel.setMaximumSize(dimensionBoton);

		panel.add(bOK);
		panel.add(bCancel);
		return panel;
	}

	public Usuario getUsuario() {

		return usuario;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == bOK) {
			usuario = new Usuario(txUsuario.getText(), String.valueOf(txContrasenia.getPassword()));
			this.dispose();
		}
		if (e.getSource() == bCancel) {
			this.dispose();
		}

	}

}