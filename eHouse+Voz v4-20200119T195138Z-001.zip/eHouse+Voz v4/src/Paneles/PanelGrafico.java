package Paneles;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class PanelGrafico extends JPanel {
	private static final long serialVersionUID = 1L;
	private static final String FICHERO_CONSUMO = "datosConsumoDisp.txt";
	private static final String SEPARADOR = "[$]";
	String[] semana1;
	String[] semana2;
	DefaultCategoryDataset dataset;
	boolean tipoGrafico;

	public PanelGrafico(boolean tipoGrafico) {
		semana1 = new String[7];
		semana2 = new String[7];
		leerDatosConsumoDesdeFichero();
		dataset = new DefaultCategoryDataset();
		this.tipoGrafico = tipoGrafico;
		this.setBackground(Color.WHITE);
		this.setLayout(new BorderLayout(25, 25));
		this.add(crearPanelGrafico());

	}

	private Container crearPanelGrafico() {
		JFreeChart chart;
		
		dataset.setValue(Double.parseDouble(semana1[0]), "semana 1", "Lunes");
		dataset.setValue(Double.parseDouble(semana1[1]), "semana 1", "Martes");
		dataset.setValue(Double.parseDouble(semana1[2]), "semana 1", "Mi�rcoles");
		dataset.setValue(Double.parseDouble(semana1[3]), "semana 1", "Jueves");
		dataset.setValue(Double.parseDouble(semana1[4]), "semana 1", "Viernes");
		dataset.setValue(Double.parseDouble(semana1[5]), "semana 1", "S�bado");
		dataset.setValue(Double.parseDouble(semana1[6]), "semana 1", "Domingo");

		dataset.setValue(Double.parseDouble(semana2[0]), "semana 2", "Lunes");
		dataset.setValue(Double.parseDouble(semana2[1]), "semana 2", "Martes");
		dataset.setValue(Double.parseDouble(semana2[2]), "semana 2", "Mi�rcoles");
		dataset.setValue(Double.parseDouble(semana2[3]), "semana 2", "Jueves");
		dataset.setValue(Double.parseDouble(semana2[4]), "semana 2", "Viernes");
		dataset.setValue(Double.parseDouble(semana2[5]), "semana 2", "S�bado");
		dataset.setValue(Double.parseDouble(semana2[6]), "semana 2", "Domingo");

		if (tipoGrafico) {
			chart = ChartFactory.createBarChart("Consumo", "d�a",

					"Kw", dataset, PlotOrientation.VERTICAL, true, true, false);
		} else {

			chart = ChartFactory.createLineChart("Consumo", "d�a",

					"Kw", dataset);
		}

		ChartPanel panel = new ChartPanel(chart);
		return panel;
	}

	private void leerDatosConsumoDesdeFichero() {
		int fila = 0;
		try (BufferedReader in = new BufferedReader(new FileReader("files/" + FICHERO_CONSUMO))) {

			String linea;
			while ((linea = in.readLine()) != null) {
				String[] valores = linea.split(SEPARADOR);
				if (fila == 0) {
					for (int i = 0; i < 7; i++) {
						semana1[i] = valores[i];
					}
				} else {
					for (int i = 0; i < 7; i++) {
						semana2[i] = valores[i];
					}
				}
				fila++;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
