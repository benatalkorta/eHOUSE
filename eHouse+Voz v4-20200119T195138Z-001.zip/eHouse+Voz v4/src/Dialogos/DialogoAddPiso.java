package Dialogos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Objetos.Piso;

public class DialogoAddPiso extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1L;
	Piso piso = null;

	JTextField txNum;
	JButton bOK, bCancel;

	public DialogoAddPiso(JFrame ventana) {
		super(ventana, "A�adir piso", true);
		this.setSize(250, 160);
		this.setLocationRelativeTo(ventana);
		this.setContentPane(crearPanelVentana());
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	private Container crearPanelVentana() {
		JPanel panel = new JPanel(new BorderLayout(0, 10));
		panel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

		panel.add(crearPanelDatos(), BorderLayout.CENTER);
		panel.add(crearPanelBotones(), BorderLayout.SOUTH);
		panel.setBackground(Color.WHITE);
		return panel;
	}

	private Component crearPanelDatos() {
		JPanel panel = new JPanel(new BorderLayout(10, 10));
		panel.setBackground(Color.WHITE);
		JLabel labelTitulo = new JLabel("Numero de Piso");
		labelTitulo.setFont(new Font("Agency FB", Font.BOLD, 25));
		panel.add(labelTitulo, BorderLayout.WEST);
		txNum = new JTextField(10);
		txNum.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "N� Piso"));
		panel.add(txNum, BorderLayout.CENTER);
		return panel;
	}

	private Component crearPanelBotones() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);

		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 0));
		panel.setAlignmentX(0.f);
		bOK = new JButton("  Ok  ");
		bOK.setActionCommand("ok");
		bOK.addActionListener(this);
		bCancel = new JButton("Cancel");
		bCancel.addActionListener(this);

		panel.add(bOK);
		panel.add(bCancel);
		return panel;
	}

	public Piso getPiso() {
		return piso;
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		if (evt.getActionCommand().equals("ok")) {
			try {
				piso = new Piso(Integer.parseInt(txNum.getText()));
				this.dispose();
			} catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(this, "Introduce el n�mero de piso que deseas a�adir", "ERROR!!",
						JOptionPane.ERROR_MESSAGE);
				txNum.setText("");
			}
		} else {
			this.dispose();
		}
	}
}
