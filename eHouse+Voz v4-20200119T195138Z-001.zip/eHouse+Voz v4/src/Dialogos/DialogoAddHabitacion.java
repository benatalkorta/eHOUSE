package Dialogos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Objetos.Habitacion;
import Principal.Principal;

public class DialogoAddHabitacion extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1L;
	Habitacion habitacion = null;
	Principal principal;
	JTextField txNum;
	JButton bOK, bCancel;

	public DialogoAddHabitacion(Principal ventana) {
		super(ventana, "A�adir habitacion", true);
		this.principal = ventana;
		this.setSize(300, 160);
		this.setLocationRelativeTo(ventana);
		this.setContentPane(crearPanelVentana());
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}

	private Container crearPanelVentana() {
		JPanel panel = new JPanel(new BorderLayout(0, 10));
		panel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

		panel.add(crearPanelDatos(), BorderLayout.CENTER);
		panel.add(crearPanelBotones(), BorderLayout.SOUTH);
		panel.setBackground(Color.WHITE);
		return panel;
	}

	private Component crearPanelDatos() {
		JPanel panel = new JPanel(new BorderLayout(10, 10));
		panel.setBackground(Color.WHITE);
		JLabel labelTitulo = new JLabel("A�adir Habitacion");
		labelTitulo.setFont(new Font("Agency FB", Font.BOLD, 25));
		panel.add(labelTitulo, BorderLayout.WEST);
		txNum = new JTextField(20);
		txNum.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Nombre"));
		panel.add(txNum, BorderLayout.CENTER);
		return panel;
	}

	private Component crearPanelBotones() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);

		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 0));
		panel.setAlignmentX(0.f);
		bOK = new JButton("  Ok  ");
		bOK.setActionCommand("ok");
		bOK.addActionListener(this);
		bCancel = new JButton("Cancel");
		bCancel.addActionListener(this);

		panel.add(bOK);
		panel.add(bCancel);
		return panel;
	}

	public Habitacion getHabitacion() {
		return habitacion;
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		if (evt.getActionCommand().equals("ok")) {
			if (txNum.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "Introduce el nombre de la habitaci�n que deseas a�adir", "ERROR!!",
						JOptionPane.ERROR_MESSAGE);
			} else {
				habitacion = new Habitacion(txNum.getText());
				this.dispose();
			}
		} else {
			this.dispose();
		}
	}
}
