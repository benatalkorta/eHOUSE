package Paneles;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import Controladores.ControladorPrincipal;
import Objetos.Reloj;
import Principal.Principal;

public class PanelPrincipal extends JPanel implements ActionListener {

	private static final long serialVersionUID = 1L;
	
	JLabel lHora;
	Principal ventana;
	ControladorPrincipal controladorPrincipal;
	Reloj reloj;
	JButton bNormal;
	JButton bConfiguracion;
	
	public PanelPrincipal(Principal ventana) {
		this.ventana = ventana;
		this.controladorPrincipal = new ControladorPrincipal(ventana);
		lHora = new JLabel("", SwingConstants.CENTER);
		reloj = new Reloj(500, this);
		reloj.empezar();
		
		this.setBackground(Color.WHITE);
		this.setLayout(new BorderLayout(25, 25));
		this.setBorder(BorderFactory.createEmptyBorder(30, 50, 50, 50));
		this.add(crealPanelSalir(), BorderLayout.NORTH);
		this.add(crealPanelCentral(), BorderLayout.CENTER);
	}
	
	private Component crealPanelSalir() {
		JPanel panel = new JPanel(new BorderLayout(20, 20));
		JButton bSal = new JButton(new ImageIcon("img/exit.png"));
		bSal.setToolTipText("Cerrar");
		bSal.addActionListener(this);
		bSal.setBorderPainted(false);
		bSal.setFocusPainted(false);
		bSal.setContentAreaFilled(false);
		panel.add(bSal, BorderLayout.EAST);
		panel.setBackground(Color.WHITE);
		return panel;
	}
	
	private Component crealPanelCentral() {
		JPanel panel = new JPanel(new BorderLayout(0, 0));
		panel.add(crealPanelLogo(), BorderLayout.NORTH);
		panel.add(crearPanelBotones(), BorderLayout.CENTER);
		panel.setBackground(Color.WHITE);
		return panel;
	}
	
	private Component crealPanelLogo() {
		JPanel panel = new JPanel(new BorderLayout(10,10));
		JLabel logo = new JLabel(new ImageIcon("img/logo.png"));
		panel.add(logo,BorderLayout.NORTH);
		
		lHora.setFont(new Font("calibri", Font.ITALIC, 40));
		panel.add(lHora,BorderLayout.SOUTH);
		
		panel.setBackground(Color.WHITE);
		return panel;
	}
	
	private Component crearPanelBotones() {
		JPanel panel = new JPanel(new GridLayout(2,1));
		panel.setBorder(BorderFactory.createEmptyBorder(20, 0, 80, 0));
		bNormal = new JButton(new ImageIcon("img/bNormal.png"));
		bNormal.setToolTipText("Entrar en modo Normal");
		bNormal.setBorderPainted(false);
		bNormal.setFocusPainted(false);
		bNormal.setContentAreaFilled(false);
		bNormal.setActionCommand("normal");
		bNormal.addActionListener(controladorPrincipal);
		bConfiguracion = new JButton(new ImageIcon("img/bConfig.png"));
		bConfiguracion.setToolTipText("Entrar en modo Configuracion");
		bConfiguracion.setBorderPainted(false);
		bConfiguracion.setFocusPainted(false);
		bConfiguracion.setContentAreaFilled(false);
		bConfiguracion.setActionCommand("configuracion");
		bConfiguracion.addActionListener(controladorPrincipal);
		panel.add(bNormal);
		panel.add(bConfiguracion);
		panel.setBackground(Color.WHITE);
		return panel;
	}
	

	public Principal getVentana() {
		return ventana;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == reloj) {
			this.lHora.setText(ZonedDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
		} else {
			ventana.dispose();
			System.exit(0);
		}
	}
	
}
