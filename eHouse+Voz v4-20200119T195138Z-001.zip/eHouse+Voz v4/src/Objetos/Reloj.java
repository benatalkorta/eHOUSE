package Objetos;


import java.awt.event.ActionListener;

import javax.swing.Timer;

public class Reloj extends Timer {
	
	private static final long serialVersionUID = 1L;
	
	public Reloj(int ratio, ActionListener listener) {
		super(ratio, listener);
		this.setRepeats(true);    
		this.setInitialDelay(0);
	}
	
	public void empezar() {
		this.start();
	}

}
