package Paneles;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JToolBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import Componentes.TablaProgramas;
import Dialogos.DialogoAddPrograma;
import Objetos.Dispositivo;
import Objetos.DispositivoProgramable;
import Objetos.DispositivoRegulable;
import Objetos.Programa;
import Principal.Principal;

public class PanelDispositivo extends JPanel implements ChangeListener, ActionListener {

	private static final long serialVersionUID = 1L;
	Dispositivo dispositivo;
	JSlider sNivel;
	DispositivoRegulable dispReg;
	Principal ventana;
	TablaProgramas tablaProgramas;

	public PanelDispositivo(Principal ventana, Dispositivo dispositivo, boolean esModoConfig) {
		this.setBackground(Color.WHITE);
		this.setLayout(new BorderLayout());
		this.dispositivo = dispositivo;
		this.ventana = ventana;
		if (this.dispositivo != null) {
			this.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLoweredBevelBorder(),
					"Dispositivo: " + this.dispositivo.getNombre(), 0, 0, new Font("Calibri", Font.ITALIC, 20),
					Color.BLUE));
			if (this.dispositivo instanceof DispositivoRegulable)
				crearPanelRegulable();
			else if (this.dispositivo instanceof DispositivoProgramable) {
				crearPanelProgramable();
				if (esModoConfig) {
					this.add(crearToolBar(), BorderLayout.NORTH);
				}
			}
		}
	}

	private Component crearToolBar() {
		JToolBar barra = new JToolBar();
		barra.setFloatable(false);
		barra.add(crearBotonA�adirProg());
		barra.add(crearBotonQuitarProg());
		barra.setBackground(Color.WHITE);
		return barra;
	}

	private JButton crearBotonA�adirProg() {
		JButton bA�adirProg = crearBoton("A�adir Programa", "add_programa", "img/add.png");
		return bA�adirProg;
	}

	private JButton crearBotonQuitarProg() {
		JButton bDelProg = crearBoton("Eliminar Programa", "del_programa", "img/del.png");
		return bDelProg;
	}

	private JButton crearBoton(String toolTipText, String actionCommand, String imagen) {
		JButton boton = new JButton(new ImageIcon(imagen));
		boton.setToolTipText(toolTipText);
		boton.setBorderPainted(false);
		boton.setFocusPainted(false);
		boton.setContentAreaFilled(false);
		boton.setActionCommand(actionCommand);
		boton.addActionListener(this);

		return boton;
	}

	private void crearPanelProgramable() {
		DispositivoProgramable dispProg = (DispositivoProgramable) dispositivo;
		JScrollPane lista = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		tablaProgramas = new TablaProgramas(dispProg);
		lista.setViewportView(tablaProgramas);
		lista.getViewport().setBackground(Color.white);
		this.add(lista);
		this.setBackground(Color.white);
		
	}

	private void crearPanelRegulable() {
		dispReg = (DispositivoRegulable) dispositivo;
		sNivel = new JSlider(JSlider.HORIZONTAL, 0, 100, dispReg.getNivel());
		sNivel.setMajorTickSpacing(25);
		sNivel.setPaintTicks(true);
		sNivel.setBackground(Color.WHITE);
		sNivel.setFont(new Font("Calibri", Font.PLAIN, 20));
		sNivel.setPaintLabels(true);
		sNivel.addChangeListener(this);
		this.add(sNivel, BorderLayout.CENTER);
	}

	@Override
	public void stateChanged(ChangeEvent evt) {
		if (evt.getSource() == sNivel) {
			if (!sNivel.getValueIsAdjusting()) {
				dispReg.setNivel(sNivel.getValue());
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		DispositivoProgramable disp;
		switch (e.getActionCommand()) {

		case "add_programa":
			disp = (DispositivoProgramable) dispositivo;
			DialogoAddPrograma dialogo = new DialogoAddPrograma(disp, ventana);
			Programa p = dialogo.getPrograma();
			if (p != null) {
				disp.addPrograma(p);
				p.addPropertyChangeListener(disp);
				ventana.getCasa().guardarCasaEnFichero();
			}
			break;
		default:
			disp = (DispositivoProgramable) dispositivo;
			if ((tablaProgramas.getSelectedRow()) != -1) {
				Programa prog = disp.getListaProgramas()
						.get(tablaProgramas.convertRowIndexToModel(tablaProgramas.getSelectedRow()));
				if (prog != null) {
					int numProgramas = disp.getListaProgramas().size();
					int numPrograma = prog.getId();
					disp.removePrograma(prog);
					disp.reordenar(numPrograma, numProgramas);
					ventana.getCasa().guardarCasaEnFichero();
				}

			}
		}

	}

}
