package Objetos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractListModel;

public class Piso extends AbstractListModel<Habitacion> implements Serializable {

	private static final long serialVersionUID = 1L;
	int num;
	List<Habitacion> listaHabitaciones;

	public Piso(int num) {
		super();
		this.num = num;
		listaHabitaciones = new ArrayList<>();
	}

	public void setNum(int num) {
		this.num = num;
	}

	public boolean contieneHabitacion(Habitacion h) {
		return listaHabitaciones.contains(h);
	}

	public void addHabitacion(Habitacion h) {
		listaHabitaciones.add(h);
		super.fireContentsChanged(listaHabitaciones, 0, listaHabitaciones.size());
	}

	public void removeHabitacion(Habitacion h) {
		listaHabitaciones.remove(h);
		super.fireContentsChanged(listaHabitaciones, 0, listaHabitaciones.size());
	}

	public List<Habitacion> getListHabitaciones() {
		return listaHabitaciones;
	}

	public int getNum() {
		return num;
	}

	@Override
	public String toString() {
		return "Piso " + num;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (!(obj instanceof Piso))
			return false;
		Piso piso = (Piso) obj;
		if (this.num != piso.getNum())
			return false;
		return true;
	}

	@Override
	public int hashCode() {

		return String.valueOf(num).hashCode();
	}

	@Override
	public Habitacion getElementAt(int index) {
		return listaHabitaciones.get(index);
	}

	@Override
	public int getSize() {
		return listaHabitaciones.size();
	}

}
