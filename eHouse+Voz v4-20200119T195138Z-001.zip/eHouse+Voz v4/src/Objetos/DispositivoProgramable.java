package Objetos;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;

import Modelos.ModeloTablaProgramas;

public class DispositivoProgramable extends Dispositivo implements PropertyChangeListener {

	private static final long serialVersionUID = 1L;
	List<Programa> listaProgramas;
	ModeloTablaProgramas modeloTabla;

	public DispositivoProgramable(int id, String nombre, double consumo) {
		super(id, nombre, consumo);
		this.listaProgramas = new ArrayList<>();
		modeloTabla = new ModeloTablaProgramas();
	}

	public void addPrograma(Programa p) {
		this.listaProgramas.add(p);
		modeloTabla.add(p);
	}

	public void reordenar(int numPrograma, int numProgramas) {
		if (numPrograma != numProgramas) {
			int id = numPrograma;
			for (int i = numPrograma; i < numProgramas; i++) {
				listaProgramas.get(i - 1).setId(id);
				id++;
			}
		}
	}

	public void apagarTodosLosDispositivos() {
		for (Programa p : listaProgramas) {
			if (p.isEncendido()) {
				p.apagar();
			}
		}
	}

	public void removePrograma(Programa p) {
		this.listaProgramas.remove(p);
		modeloTabla.remove(p);
	}

	public boolean AlgunDispositivoEncendido() {
		for (Programa p : listaProgramas) {
			if (p.isEncendido()) {
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (!(obj instanceof Dispositivo))
			return false;
		Dispositivo disp = (Dispositivo) obj;
		if (disp instanceof DispositivoRegulable)
			return false;
		if (disp instanceof DispositivoProgramable) {
			if (!this.nombre.toLowerCase().equals(disp.getNombre().toLowerCase())) {
				return false;
			} else {
				return true;
			}
		} else {
			return false;
		}
	}

	public ModeloTablaProgramas getModeloTabla() {
		return modeloTabla;
	}

	public List<Programa> getListaProgramas() {
		return listaProgramas;
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		if (super.encendido) {
			if (AlgunDispositivoEncendido()) {
				apagarTodosLosDispositivos();
			}
			Programa p = (Programa) evt.getNewValue();
			p.encender();
		}
	}

	@Override
	public void apagar() {
		super.apagar();
		for (Programa p : listaProgramas) {
			if (p.isEncendido())
				p.apagar();
		}
	}
}
