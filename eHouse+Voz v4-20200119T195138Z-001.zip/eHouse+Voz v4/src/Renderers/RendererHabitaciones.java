package Renderers;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;

import Objetos.Habitacion;

public class RendererHabitaciones implements ListCellRenderer<Habitacion> {

	@Override
	public Component getListCellRendererComponent(JList<? extends Habitacion> list, Habitacion value, int index,
			boolean isSelected, boolean cellHasFocus) {
		JPanel panel = new JPanel();
		JLabel label = new JLabel(value.toString());
		panel.add(label);
		if (isSelected) {
			panel.setBackground(Color.MAGENTA);
		} else {
			panel.setBackground(Color.WHITE);
		}
		return panel;
	}
}
