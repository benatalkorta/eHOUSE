package Controladores;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import Dialogos.DialogoIniciarSesion;
import Objetos.Usuario;
import Principal.Principal;

public class ControladorPrincipal implements ActionListener {
	Principal principal;

	public ControladorPrincipal(Principal principal) {
		this.principal = principal;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {
		case "configuracion":
			DialogoIniciarSesion dialogo = new DialogoIniciarSesion(principal);
			Usuario usuario = dialogo.getUsuario();
			if (usuario != null) {
				if (principal.getGestorUsuarios().existeUsuario(usuario)) {					
					principal.getGestorUsuarios().setUsuarioLogeado(usuario);
					principal.entrarModoConfiguracion(usuario.getNombre());
				} else {
					JOptionPane.showMessageDialog(principal, "Usuario o contrase�a incorrectos", "ERROR!!",
							JOptionPane.ERROR_MESSAGE);
				}
			}

			break;
		case "normal":
			principal.getGestorUsuarios().setUsuarioLogeado(null);
			principal.entrarModoNormal();
			break;
		}

	}

}
