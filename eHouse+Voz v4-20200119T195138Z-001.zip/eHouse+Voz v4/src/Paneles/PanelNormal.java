package Paneles;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.MouseAdapter;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;

import Componentes.TablaDispositivos;
import Controladores.ControladorNormal;
import Controladores.ControladorVoz;
import Objetos.Dispositivo;
import Objetos.Habitacion;
import Objetos.Piso;
import Principal.Principal;
import Renderers.RendererHabitaciones;
import voz.Escucha;
import voz.Lee;
import voz.Reproductor;

public class PanelNormal extends JPanel {
	private static final long serialVersionUID = 1L;
	Principal ventana;
	JButton bDispositivos;
	JButton bConsumo;
	JComboBox<Piso> cbxpisos;
	JList<Habitacion> listaHabitaciones;
	ControladorNormal controlador;
	ControladorVoz controladorVoz;
	JScrollPane panelListaHabitaciones;
	TablaDispositivos tablaDispositivos;
	JSplitPane spanel;
	Reproductor reproductor;
	Escucha oyente;
	Lee lector;

	public PanelNormal(Principal ventana) {
		super(new BorderLayout());
		this.ventana = ventana;
		controlador = new ControladorNormal(this);
		this.setBackground(Color.WHITE);
		this.setLayout(new BorderLayout());
		InicioControlVoz();
		this.add(crealToolBar(), BorderLayout.NORTH);
		this.add(crealPanelPrincipal(), BorderLayout.CENTER);
	}

	private Component crealToolBar() {
		JToolBar barra = new JToolBar();
		barra.setFloatable(false);
		barra.add(crearMenuDispositivos());
		barra.add(crearMenuConsumo());
		barra.add(Box.createHorizontalGlue());
		barra.add(crearMenuLogo());
		barra.add(Box.createHorizontalGlue());
		barra.addSeparator();
		barra.add(crearMenuSalir());
		barra.setBackground(Color.WHITE);
		return barra;
	}

	public void InicioControlVoz() {
		reproductor = new Reproductor();
		oyente = new Escucha();
		controladorVoz = new ControladorVoz(reproductor, this);
		oyente.setControladorVoz(controladorVoz);
		oyente.empiezaEscucha();

	}

	private Component crealPanelPrincipal() {
		JSplitPane panelPrincipal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, crearPanelIzda(), crearPanelDcha());
		panelPrincipal.setBackground(Color.WHITE);
		panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		panelPrincipal.setDividerLocation(220);
		return panelPrincipal;
	}

	private Component crearPanelDcha() {
		JScrollPane panel = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);// panelArriba
		panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLoweredBevelBorder(),
				"Lista de dispositivos", 0, 0, new Font("Calibri", Font.ITALIC, 20), Color.BLUE));

		PanelDispositivo panelDispositivo = new PanelDispositivo(ventana, null, false);// panelAbajo
		spanel = new JSplitPane(JSplitPane.VERTICAL_SPLIT, panel, panelDispositivo);
		Habitacion habitacion = ventana.getCasa().getListaPisos().get(0).getListHabitaciones().get(0);
		tablaDispositivos = new TablaDispositivos(habitacion);
		tablaDispositivos.addMouseListener(new MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				int fila = tablaDispositivos.getSelectedRow();
				Habitacion h = listaHabitaciones.getSelectedValue();
				Dispositivo dispositivo = h.getDispositivos().get(fila);
				PanelDispositivo panelDispositivo = new PanelDispositivo(ventana, dispositivo, false);
				spanel.setBottomComponent(panelDispositivo);
				spanel.setDividerLocation(300);

			}
		});
		panel.setViewportView(tablaDispositivos);
		panel.getViewport().setBackground(Color.WHITE);
		panel.setBackground(Color.WHITE);
		spanel.setDividerLocation(300);
		spanel.setBackground(Color.WHITE);
		spanel.setBorder(null);
		return spanel;

	}

	private Component crearPanelIzda() {
		JPanel panel = new JPanel(new BorderLayout(10, 10));
		panel.setBackground(Color.WHITE);
		panel.add(crearPanelArriba(), BorderLayout.NORTH);
		panel.add(crearPanelListaHabitaciones(), BorderLayout.CENTER);
		return panel;
	}

	private Component crearPanelArriba() {
		JPanel panel = new JPanel(new BorderLayout(10, 10));
		panel.setBackground(Color.WHITE);
		panel.add(crearPanelPisos(), BorderLayout.NORTH);
		panel.add(crearPanelEditarHabitaciones(), BorderLayout.CENTER);
		return panel;
	}

	private Component crearPanelEditarHabitaciones() {
		JPanel panel = new JPanel(new BorderLayout(10, 10));
		panel.setBorder(BorderFactory.createLineBorder(Color.MAGENTA));
		panel.setBackground(Color.WHITE);
		panel.add(crearLabelHabitas(), BorderLayout.CENTER);
		return panel;
	}

	private Component crearLabelHabitas() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.white);
		JLabel label = new JLabel("Habitaciones");
		label.setFont(new Font("Agency FB", Font.BOLD, 20));
		panel.add(label);
		return panel;
	}

	private Component crearPanelListaHabitaciones() {
		panelListaHabitaciones = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		RendererHabitaciones renderer = new RendererHabitaciones();
		listaHabitaciones = new JList<>();
		try {
			listaHabitaciones.setModel(ventana.getCasa().getElementAt(0));
		} catch (IllegalArgumentException e) {

		}
		listaHabitaciones.setCellRenderer(renderer);
		listaHabitaciones.setSelectedIndex(0);
		listaHabitaciones.addListSelectionListener(controlador);
		panelListaHabitaciones.setViewportView(listaHabitaciones);
		return panelListaHabitaciones;
	}

	private Component crearPanelPisos() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBackground(Color.WHITE);
		cbxpisos = new JComboBox<>(ventana.getCasa().getComboBoxModelo());
		cbxpisos.addItemListener(controlador);
		panel.add(cbxpisos, BorderLayout.CENTER);
		return panel;
	}

	public JMenuBar crearBarraMenu(String usuario) {
		JMenuBar barra = new JMenuBar();
		barra.setBackground(Color.WHITE);
		barra.add(crearMenuDispositivos());
		barra.add(crearMenuConsumo());
		barra.add(Box.createHorizontalGlue());
		barra.add(crearLabelUsuario(usuario));
		barra.add(Box.createHorizontalGlue());
		barra.add(crearMenuLogo());
		barra.add(Box.createHorizontalGlue());
		barra.add(crearMenuSalir());
		return barra;
	}

	public JLabel crearLabelUsuario(String usuario) {
		JLabel label = new JLabel(usuario);
		label.setFont(new Font("Agency FB", Font.BOLD, 40));
		return label;
	}

	private JLabel crearMenuLogo() {
		JLabel labelLogo = new JLabel(new ImageIcon("img/logoPeque�o.png"));
		return labelLogo;
	}

	private Component crearMenuConsumo() {
		bConsumo = new JButton(new ImageIcon("img/bconsumo.png"));
		bConsumo.setToolTipText("Mostrar la pantalla del consumo de la casa");
		bConsumo.setBorderPainted(false);
		bConsumo.setFocusPainted(false);
		bConsumo.setContentAreaFilled(false);
		bConsumo.setActionCommand("consumo");
		bConsumo.addActionListener(controlador);
		return bConsumo;
	}

	private Component crearMenuDispositivos() {
		bDispositivos = new JButton(new ImageIcon("img/bdispositivos.png"));
		bDispositivos.setToolTipText("Mostrar la pantalla de los dispositivos de la casa");
		bDispositivos.setBorderPainted(false);
		bDispositivos.setFocusPainted(false);
		bDispositivos.setContentAreaFilled(false);
		bDispositivos.setEnabled(false);
		bDispositivos.setActionCommand("dispositivos");
		bDispositivos.addActionListener(controlador);
		return bDispositivos;
	}

	private Component crearMenuSalir() {
		JButton bSalir = new JButton(new ImageIcon("img/bsalir.png"));
		bSalir.setToolTipText("Ir a pantalla principal");
		bSalir.setBorderPainted(false);
		bSalir.setFocusPainted(false);
		bSalir.setContentAreaFilled(false);
		bSalir.setActionCommand("salir");
		bSalir.addActionListener(controlador);
		return bSalir;
	}

	public JComboBox<Piso> getCbxpisos() {
		return cbxpisos;
	}

	public Principal getVentana() {
		return ventana;
	}

	public JList<Habitacion> getListaHabitaciones() {
		return listaHabitaciones;
	}

	public TablaDispositivos getTablaDispositivos() {
		return tablaDispositivos;
	}

	public JButton getbDispositivos() {
		return bDispositivos;
	}

	public JButton getbConsumo() {
		return bConsumo;
	}

	public JScrollPane getPanelListaHabitaciones() {
		return panelListaHabitaciones;
	}

	public JSplitPane getSpanel() {
		return spanel;
	}

}
