package Paneles;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;

import Objetos.Consumo;
import Principal.Principal;

public class PanelConsumo extends JPanel implements ItemListener, ActionListener {
	private static final long serialVersionUID = 1L;
	JPanel panelGrafico;
	Principal ventana;
	JRadioButton rGraficoBarras, rGraficoLineas;
	ButtonGroup tiposGrafico;
	JPanel panelRButtons;
	Consumo consumo;
	JLabel lTemperaturaAgua, lEstadoCaldera, lEnergiaConsumiendose, lTemperaturaCasa, lTemperaturaExterior,
			lTemperaturaDeseada;
	JSlider sTemperaturaDeseada;

	public PanelConsumo(Principal ventana) {
		super(new BorderLayout());
		this.ventana = ventana;
		consumo = ventana.getCasa().getConsumo();
		this.setBackground(Color.WHITE);
		this.setLayout(new BorderLayout(25, 25));
		this.add(crealToolBar(), BorderLayout.NORTH);
		this.add(crearPanelVentana(), BorderLayout.CENTER);
	}

	private Component crealToolBar() {
		JToolBar barra = new JToolBar();
		barra.setFloatable(false);
		barra.add(crearMenuDispositivos());
		barra.add(crearMenuConsumo());
		barra.add(Box.createHorizontalGlue());
		barra.add(crearMenuLogo());
		barra.add(Box.createHorizontalGlue());
		barra.addSeparator();
		barra.add(crearMenuSalir());
		barra.setBackground(Color.WHITE);
		return barra;
	}

	public JLabel crearLabelUsuario(String usuario) {
		JLabel label = new JLabel(usuario);
		label.setFont(new Font("Agency FB", Font.BOLD, 40));
		return label;
	}

	private JLabel crearMenuLogo() {
		JLabel labelLogo = new JLabel(new ImageIcon("img/logoPeque�o.png"));
		return labelLogo;
	}

	private Component crearMenuConsumo() {
		JButton bConsumo = new JButton(new ImageIcon("img/bconsumo.png"));
		bConsumo.setToolTipText("Mostrar la pantalla del consumo de la casa");
		bConsumo.setBorderPainted(false);
		bConsumo.setFocusPainted(false);
		bConsumo.setContentAreaFilled(false);
		bConsumo.setEnabled(false);
		bConsumo.setActionCommand("consumo");
		return bConsumo;
	}

	private Component crearMenuDispositivos() {
		JButton bDispositivos = new JButton(new ImageIcon("img/bdispositivos.png"));
		bDispositivos.setToolTipText("Mostrar la pantalla de los dispositivos de la casa");
		bDispositivos.setBorderPainted(false);
		bDispositivos.setFocusPainted(false);
		bDispositivos.setContentAreaFilled(false);
		bDispositivos.setActionCommand("dispositivos");
		bDispositivos.addActionListener(this);
		return bDispositivos;
	}

	private Component crearMenuSalir() {
		JButton bSalir = new JButton(new ImageIcon("img/bsalir.png"));
		bSalir.setToolTipText("Ir a pantalla principal");
		bSalir.setBorderPainted(false);
		bSalir.setFocusPainted(false);
		bSalir.setContentAreaFilled(false);
		bSalir.setActionCommand("salir");
		bSalir.addActionListener(this);
		return bSalir;
	}

	private Container crearPanelVentana() {
		JSplitPane panel = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, crearPanelCentro(), crearPanelDerecha());
		panel.setDividerLocation(900);
		return panel;
	}

	private Component crearPanelDerecha() {
		JPanel panel = new JPanel(new BorderLayout(30, 30));
		panel.setBackground(Color.WHITE);
		panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		panel.add(crearPanelDatos(), BorderLayout.SOUTH);
		panel.add(crearPanelDato1(), BorderLayout.CENTER);

		return panel;
	}

	private Component crearPanelDatos() {
		JPanel panel = new JPanel(new GridLayout(5, 1, 30, 30));
		panel.setBackground(Color.WHITE);

		panel.add(crearPanelDato2());
		panel.add(crearPanelDato3());
		panel.add(crearPanelDato4());
		panel.add(crearPanelDato5());
		panel.add(crearPanelDato6());

		return panel;
	}

	private Component crearPanelDato1() {
		JPanel panel = new JPanel(new BorderLayout(0, 0));
		panel.setBackground(Color.WHITE);
		panel.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Temperatura Deseada"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		sTemperaturaDeseada = new JSlider(0, 30, 0);
		sTemperaturaDeseada.setValue(20);
		sTemperaturaDeseada.setBackground(Color.WHITE);
		panel.add(sTemperaturaDeseada, BorderLayout.CENTER);

		lTemperaturaDeseada = new JLabel(consumo.getTemperaturaDeseada() + " �C");
		panel.add(lTemperaturaDeseada, BorderLayout.NORTH);
		sTemperaturaDeseada.addChangeListener((ChangeEvent event) -> {

			int value = sTemperaturaDeseada.getValue();
			consumo.setTemperaturaDeseada(value);
			lTemperaturaDeseada.setText(consumo.getTemperaturaDeseada() + " �C");
			if (consumo.getTemperaturaDeseada() > consumo.getTemperaturaCasa()) {
				consumo.setEstadoCaldera(true);
				lEstadoCaldera.setText("ON");
			} else {
				consumo.setEstadoCaldera(false);
				lEstadoCaldera.setText("OFF");
			}
		});
		return panel;
	}

	private Component crearPanelDato2() {
		lTemperaturaAgua = new JLabel(String.valueOf(consumo.getTemperaturaAgua() + " �C"));
		lTemperaturaAgua.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Temperatura Agua"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		return lTemperaturaAgua;
	}

	private Component crearPanelDato3() {
		lEnergiaConsumiendose = new JLabel(String.valueOf(consumo.getEnergiaConsumiendose() + " kW"));
		lEnergiaConsumiendose.setBorder(BorderFactory.createCompoundBorder(BorderFactory
				.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Energ�a Consumi�ndose"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		return lEnergiaConsumiendose;
	}

	private Component crearPanelDato4() {
		if (consumo.isEstadoCaldera() == true) {
			lEstadoCaldera = new JLabel(String.valueOf("ON"));
		} else {
			lEstadoCaldera = new JLabel(String.valueOf("OFF"));
		}

		lEstadoCaldera.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Estado Caldera"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		return lEstadoCaldera;
	}

	private Component crearPanelDato5() {
		lTemperaturaCasa = new JLabel(String.valueOf(consumo.getTemperaturaCasa() + " �C"));
		lTemperaturaCasa.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Temperatura Casa"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		return lTemperaturaCasa;
	}

	private Component crearPanelDato6() {
		lTemperaturaExterior = new JLabel(String.valueOf(consumo.getTemperaturaExterior() + " �C"));
		lTemperaturaExterior.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Temperatura Exterior"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		return lTemperaturaExterior;
	}

	private Component crearPanelCentro() {
		panelGrafico = new JPanel(new BorderLayout());
		panelGrafico.add(new PanelGrafico(true), BorderLayout.CENTER);
		panelGrafico.add(crearPanelAbajo(), BorderLayout.SOUTH);
		return panelGrafico;
	}

	private Component crearPanelAbajo() {
		JPanel panel= new JPanel(new GridLayout(3,1));
		JLabel lSem1,lSem2;
		lSem1= new JLabel("*Semana 1: Hace dos semanas",SwingConstants.CENTER);
		lSem2= new JLabel("*Semana 2: Hace una semana",SwingConstants.CENTER);
		panel.setBackground(Color.white);
		panel.add(lSem1);
		panel.add(lSem2);
		panel.add(crearPanelRadioButtons());
		return panel;
	}

	private Component crearPanelRadioButtons() {
		panelRButtons = new JPanel(new FlowLayout());
		panelRButtons.setBackground(Color.WHITE);
		rGraficoBarras = new JRadioButton("Gr�fico de Barras");
		rGraficoBarras.setBackground(Color.WHITE);
		rGraficoBarras.addItemListener(this);
		rGraficoLineas = new JRadioButton("Gr�fico de L�neas");
		rGraficoLineas.setBackground(Color.WHITE);
		rGraficoLineas.addItemListener(this);
		tiposGrafico = new ButtonGroup();
		tiposGrafico.add(rGraficoBarras);
		tiposGrafico.add(rGraficoLineas);
		rGraficoBarras.setSelected(true);
		panelRButtons.add(rGraficoBarras);
		panelRButtons.add(rGraficoLineas);
		return panelRButtons;
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
			if (e.getSource() == rGraficoBarras) {
				panelGrafico.removeAll();
				panelGrafico.add(new PanelGrafico(true), BorderLayout.CENTER);
			} else {
				panelGrafico.removeAll();
				panelGrafico.add(new PanelGrafico(false), BorderLayout.CENTER);
			}
			panelGrafico.add(panelRButtons, BorderLayout.SOUTH);
			ventana.repaint();
			ventana.revalidate();
		}

	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		switch (evt.getActionCommand()) {
		case "salir":
			ventana.entrarModoPrincipal();
			break;
		default:
			ventana.entrarModoNormal();
			break;
		}

	}
}
