package Objetos;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;

public class Programa implements Serializable {

	private static final long serialVersionUID = 1L;
	String nombre;
	int id;
	boolean encendido;
	PropertyChangeSupport soporte;

	public Programa(int id, String nombre) {
		this.id = id;
		this.nombre = nombre;
		this.encendido = false;
		soporte = new PropertyChangeSupport(this);
	}

	public void addPropertyChangeListener(PropertyChangeListener listener) {
		soporte.addPropertyChangeListener(listener);
	}

	public void setId(int id) {
		this.id = id;
	}

	public void encender() {
		encendido = true;
	}

	public void apagar() {
		encendido = false;
	}

	public void power() {

		if (!encendido) {
			soporte.firePropertyChange("encender_programa", null, this);
		} else {
			apagar();
		}

	}

	public boolean isEncendido() {
		return encendido;
	}

	public void setEncendido(boolean encendido) {
		this.encendido = encendido;
	}

	public String getNombre() {
		return nombre;
	}

	public Object getFieldAt(int columna) {
		switch (columna) {
		case 0:
			return id;
		case 1:
			return nombre;
		case 2:
			return encendido;
		default:
			return null;
		}
	}

	public Class<?> getFieldClass(int indice) {
		switch (indice) {
		case 0:
			return Integer.class;
		case 1:
			return String.class;
		case 2:
			return Boolean.class;
		default:
			return String.class;
		}

	}

	public int getId() {
		return id;
	}

}
