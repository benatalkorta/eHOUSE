package voz;

import javax.speech.*;
import javax.speech.recognition.*;

import Controladores.ControladorVoz;

import java.io.FileReader;
import java.util.Locale;

public class Escucha extends ResultAdapter {

	static Recognizer recognizer;
	ControladorVoz controladorVoz;

	public void setControladorVoz(ControladorVoz controladorVoz) {
		this.controladorVoz = controladorVoz;
	}

	public void empiezaEscucha() {
		try {
			recognizer = Central.createRecognizer(new EngineModeDesc(Locale.ROOT));
			recognizer.allocate();

			FileReader grammar1 = new FileReader("files/diccionario.txt");

			RuleGrammar rg = recognizer.loadJSGF(grammar1);
			rg.setEnabled(true);

			recognizer.addResultListener(this);

			System.out.println("Empiece Dictado");
			recognizer.commitChanges();

			recognizer.requestFocus();
			recognizer.resume();
		} catch (Exception e) {
			System.out.println("Exception en " + e.toString());
			e.printStackTrace();
			System.exit(0);
		}
	}

	@Override
	public void resultAccepted(ResultEvent re) {

		Result res = (Result) (re.getSource());
		ResultToken tokens[] = res.getBestTokens();
		int aux = 0;
		String concatenado[] = new String[5];

		for (int i = 0; i < tokens.length; i++) {
			concatenado[aux] = tokens[i].getSpokenText();
			System.out.println(concatenado[aux] + " ");
			aux++;
		}

		switch (tokens.length) {
		case 1:
			controladorVoz.accionesVoz(concatenado[0], "", "", 0);
			break;
		case 2:
			controladorVoz.accionesVoz(concatenado[0], concatenado[1], "", 0);
			break;
		case 3:
			controladorVoz.accionesVoz(concatenado[0], concatenado[1], concatenado[2], 0);
			break;
		case 4:
			controladorVoz.accionesVoz(concatenado[0], concatenado[1], concatenado[2],
					Integer.parseInt(concatenado[3]));
			break;
		}
		System.out.println();
	}

}