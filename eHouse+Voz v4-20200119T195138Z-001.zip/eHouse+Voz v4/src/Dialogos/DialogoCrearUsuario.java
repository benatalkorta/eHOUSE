package Dialogos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Objetos.Usuario;

public class DialogoCrearUsuario extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1L;
	Usuario usuario;
	JTextField txtNombre;
	JPasswordField txtContrase�aNueva, txtRepetirContrase�a;
	JButton bOK, bCancel;
	Dimension dimensionBoton;

	public DialogoCrearUsuario(JFrame ventana) {
		super(ventana, "Registrar Usuario", true);
		usuario = null;
		this.setSize(350, 400);
		this.setLocationRelativeTo(ventana);
		this.setContentPane(crearPanelVentana());
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}

	private Container crearPanelVentana() {
		JPanel panel = new JPanel(new BorderLayout(0, 10));
		panel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

		panel.add(crearPanelDatos(), BorderLayout.CENTER);
		panel.add(crearPanelBotones(), BorderLayout.SOUTH);
		panel.add(crearPanelTitulo(), BorderLayout.NORTH);
		panel.setBackground(Color.WHITE);
		return panel;
	}

	private Component crearPanelTitulo() {
		JPanel panel = new JPanel(new BorderLayout(10, 10));
		panel.setBackground(Color.WHITE);

		JLabel labelTitulo = new JLabel("Registrar");
		labelTitulo.setFont(new Font("Agency FB", Font.BOLD, 25));

		panel.add(labelTitulo, BorderLayout.CENTER);

		JLabel labelLogo = new JLabel(new ImageIcon("img/logoPeque�o.png"));

		panel.add(labelLogo, BorderLayout.EAST);

		return panel;
	}

	private Component crearPanelDatos() {
		JPanel panel = new JPanel(new GridLayout(3, 1, 0, 10));
		panel.setBackground(Color.WHITE);

		panel.add(crearPanelUsuario());
		panel.add(crearPanelContrase�aNueva());
		panel.add(crearPanelRepetirContrase�a());

		return panel;
	}

	private Component crearPanelRepetirContrase�a() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);

		txtRepetirContrase�a = new JPasswordField(20);
		panel.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Repite Contrase�a"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));

		panel.add(txtRepetirContrase�a);

		return panel;
	}

	private JPanel crearPanelUsuario() {
		JPanel panelUsuario = new JPanel();
		panelUsuario.setBackground(Color.WHITE);

		txtNombre = new JTextField(20);
		panelUsuario.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Usuario"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		panelUsuario.add(txtNombre);
		return panelUsuario;

	}

	private JPanel crearPanelContrase�aNueva() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);

		txtContrase�aNueva = new JPasswordField(20);
		panel.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Nueva Contrase�a"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));

		panel.add(txtContrase�aNueva);

		return panel;
	}

	private Component crearPanelBotones() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);

		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 0));
		panel.setAlignmentX(0.f);
		bOK = new JButton("  Ok  ");
		bOK.addActionListener(this);
		bOK.setPreferredSize(dimensionBoton);
		bOK.setMinimumSize(dimensionBoton);
		bOK.setMaximumSize(dimensionBoton);
		bCancel = new JButton("Cancel");
		bCancel.addActionListener(this);
		bCancel.setPreferredSize(dimensionBoton);
		bCancel.setMinimumSize(dimensionBoton);
		bCancel.setMaximumSize(dimensionBoton);

		panel.add(bOK);
		panel.add(bCancel);
		return panel;
	}

	public Usuario getUsuario() {

		return usuario;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == bOK) {

			if (!txtNombre.getText().isEmpty() & !String.valueOf(txtContrase�aNueva.getPassword()).isEmpty()
					& !String.valueOf(txtRepetirContrase�a.getPassword()).isEmpty()) {
				if (String.valueOf(txtContrase�aNueva.getPassword())
						.equals(String.valueOf(txtRepetirContrase�a.getPassword()))) {
					usuario = new Usuario(txtNombre.getText(), String.valueOf(txtContrase�aNueva.getPassword()));

					this.dispose();

				} else {
					JOptionPane.showMessageDialog(this, "Las contrase�as no coinciden", "ERROR!!",
							JOptionPane.ERROR_MESSAGE);
					txtRepetirContrase�a.setText("");
					txtContrase�aNueva.setText("");
				}
			} else {
				JOptionPane.showMessageDialog(this, "Hay campos vacios", "ERROR!!", JOptionPane.ERROR_MESSAGE);
			}

		}
		if (e.getSource() == bCancel) {
			this.dispose();
		}

	}

}