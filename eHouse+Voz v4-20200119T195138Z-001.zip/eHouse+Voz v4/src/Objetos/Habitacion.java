package Objetos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import Modelos.ModeloTablaDisposivos;

public class Habitacion implements Serializable {

	private static final long serialVersionUID = 1L;
	String nombre;
	ModeloTablaDisposivos modeloTabla;
	List<Dispositivo> dispositivos;

	public Habitacion(String nombre) {
		this.nombre = nombre;
		dispositivos = new ArrayList<>();
		modeloTabla = new ModeloTablaDisposivos();
	}

	public void addDispositivo(Dispositivo d) {
		this.dispositivos.add(d);
		this.modeloTabla.add(d);
	}

	public boolean contieneDispositivo(Dispositivo d) {
		return dispositivos.contains(d);
	}

	public ModeloTablaDisposivos getModeloTabla() {
		return modeloTabla;
	}
	
	public void reordenar(int numDispositivo, int numDispositivos) {
		if (numDispositivo != numDispositivos) {
			int id = numDispositivo;
			for (int i = numDispositivo; i < numDispositivos; i++) {
				dispositivos.get(i - 1).setId(id);
				id++;
			}
		}
	}

	public List<Dispositivo> getDispositivos() {
		return dispositivos;
	}

	public void removeDispositivo(Dispositivo d) {
		this.dispositivos.remove(d);
		this.modeloTabla.remove(d);
	}

	public String getNombre() {
		return nombre;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (!(obj instanceof Habitacion))
			return false;
		Habitacion h = (Habitacion) obj;
		if (!this.nombre.toLowerCase().equals(h.getNombre().toLowerCase()))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return nombre;
	}

}
