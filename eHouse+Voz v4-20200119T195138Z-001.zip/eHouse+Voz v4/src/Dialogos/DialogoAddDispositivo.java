package Dialogos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import Objetos.Dispositivo;
import Objetos.DispositivoProgramable;
import Objetos.DispositivoRegulable;
import Objetos.Habitacion;

public class DialogoAddDispositivo extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1L;
	Dispositivo dispositivo;
	JRadioButton rbNormal, rbProgramable, rbRegulable;
	ButtonGroup tipoDispositivo;
	JTextField txNombre, txConsumo;
	JButton bOK, bCancel;
	Habitacion habitacion;

	public DialogoAddDispositivo(Habitacion habitacion, JFrame ventana) {
		super(ventana, "A�adir dispositivo", true);
		dispositivo = null;
		this.habitacion = habitacion;
		this.setSize(350, 400);
		this.setLocationRelativeTo(ventana);
		this.setContentPane(crearPanelVentana());
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	private Container crearPanelVentana() {
		JPanel panel = new JPanel(new BorderLayout(0, 10));
		panel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

		panel.add(crearPanelDatos(), BorderLayout.CENTER);
		panel.add(crearPanelBotones(), BorderLayout.SOUTH);
		panel.add(crearPanelTitulo(), BorderLayout.NORTH);
		panel.setBackground(Color.WHITE);
		return panel;
	}

	private Component crearPanelTitulo() {
		JPanel panel = new JPanel(new BorderLayout(10, 10));
		panel.setBackground(Color.WHITE);

		JLabel labelTitulo = new JLabel("A�adir Dispositivo");
		labelTitulo.setFont(new Font("Agency FB", Font.BOLD, 25));

		panel.add(labelTitulo, BorderLayout.CENTER);

		JLabel labelLogo = new JLabel(new ImageIcon("img/logoPeque�o.png"));

		panel.add(labelLogo, BorderLayout.EAST);

		return panel;
	}

	private Container crearPanelDatos() {
		JPanel panel = new JPanel(new BorderLayout(0, 10));
		panel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
		panel.setBackground(Color.WHITE);

		panel.add(crearPanelDatos2(), BorderLayout.CENTER);
		panel.add(crearPanelButtonGroup(), BorderLayout.NORTH);

		return panel;
	}

	private Component crearPanelDatos2() {
		JPanel panel = new JPanel(new GridLayout(2, 1, 0, 10));
		panel.setBackground(Color.WHITE);

		panel.add(crearPanelNombre());
		panel.add(crearPanelConsumo());

		return panel;
	}

	private JPanel crearPanelNombre() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);

		txNombre = new JTextField(20);
		panel.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Nombre"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		panel.add(txNombre);
		return panel;

	}

	private JPanel crearPanelConsumo() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);

		txConsumo = new JTextField(20);
		panel.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.MAGENTA), "Consumo (KW)"),
				BorderFactory.createEmptyBorder(10, 10, 10, 10)));

		panel.add(txConsumo);

		return panel;
	}

	private Component crearPanelButtonGroup() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		tipoDispositivo = new ButtonGroup();

		rbNormal = new JRadioButton("Normal");
		rbNormal.setBackground(Color.WHITE);
		panel.add(rbNormal);
		tipoDispositivo.add(rbNormal);

		rbRegulable = new JRadioButton("Regulable");
		rbRegulable.setBackground(Color.WHITE);
		panel.add(rbRegulable);
		tipoDispositivo.add(rbRegulable);

		rbProgramable = new JRadioButton("Programable");
		rbProgramable.setBackground(Color.WHITE);
		panel.add(rbProgramable);
		tipoDispositivo.add(rbProgramable);

		rbNormal.setSelected(true);
		return panel;
	}

	private Component crearPanelBotones() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);

		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 0));
		panel.setAlignmentX(0.f);
		bOK = new JButton("  Ok  ");
		bOK.setActionCommand("ok");
		bOK.addActionListener(this);
		bCancel = new JButton("Cancel");
		bCancel.addActionListener(this);

		panel.add(bOK);
		panel.add(bCancel);
		return panel;
	}

	public Dispositivo getDispositivo() {
		return dispositivo;
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		if (evt.getActionCommand().equals("ok")) {
			try {
				String nombre = txNombre.getText();
				double consumo = Double.parseDouble(txConsumo.getText());
				if (rbNormal.isSelected()) {
					dispositivo = new Dispositivo(habitacion.getDispositivos().size()+1, nombre, consumo);
				} else if (rbRegulable.isSelected()) {
					dispositivo = new DispositivoRegulable(habitacion.getDispositivos().size()+1, nombre, consumo);
				} else {
					dispositivo = new DispositivoProgramable(habitacion.getDispositivos().size()+1, nombre, consumo);
				}
				this.dispose();
			} catch (NumberFormatException | NullPointerException e) {
				JOptionPane.showMessageDialog(this, "Introduce bien los datos", "ERROR!!", JOptionPane.ERROR_MESSAGE);
				txConsumo.setText("");
			}
		} else {
			this.dispose();
		}
	}
}
