package Controladores;

import Excepcciones.miExcepcion;
import Objetos.Casa;
import Objetos.Dispositivo;
import Objetos.Habitacion;
import Paneles.PanelNormal;
import voz.Lee;
import voz.Reproductor;

public class ControladorVoz {

	Reproductor reproductor;
	PanelNormal panel;
	Runnable r;
	Casa casa;
	int pisoActual;
	int habiActual;
	boolean enEscucha;

	public ControladorVoz(Reproductor reproductor, PanelNormal panel) {
		this.panel = panel;
		casa = panel.getVentana().getCasa();
		this.reproductor = reproductor;
	}

	private int encontrarHabitacion(String habitacion) {
		int kont = 0;
		for (Habitacion h : casa.getListaPisos().get(pisoActual).getListHabitaciones()) {
			if (habitacion.toLowerCase().equals(h.toString().toLowerCase())) {
				return kont;
			}
			kont++;
		}
		return -1;
	}

	private void actualizar() {
		pisoActual = panel.getCbxpisos().getSelectedIndex();
		habiActual = panel.getListaHabitaciones().getSelectedIndex();
	}

	private void encender() {
		r = new Lee("Digame");
		new Thread(r).start();
		enEscucha = true;
	}

	private void apagar() {
		enEscucha = false;
	}

	public void accionesVoz(String accion, String objeto, String objeto2, int pos) {
		System.out.println(enEscucha);
//		System.out.println("Accion: " + accion);
//		System.out.println("Objeto: " + objeto);
		switch (accion) {

		case "escucha":
			actualizar();
			if (!enEscucha) {
				encender();
			} else {
				enEscucha = false;
			}

			break;

		case "finalizar":
			if (enEscucha) {
				apagar();
			}
			break;

		case "informacion":
			if (enEscucha) {
				enEscucha = false;
				actualizar();
				r = new Lee("Piso Actual:" + (pisoActual + 1) + "Habitacion Actual:" + habitaAString());
				new Thread(r).start();
			}
			break;
		case "cambiar":
			if (enEscucha) {
				switch (objeto) {
				case "piso":
					if (pos <= casa.getListaPisos().size()) {
						pisoActual = pos - 1;
						habiActual = 0;
						panel.getCbxpisos().setSelectedIndex(pisoActual);

					} else {
						errorPisoNoEncontrado();
					}
					apagar();
					break;
				case "habitacion":
					int posHabita = encontrarHabitacion(objeto2);
					try {
						validarHabita(posHabita);
						habiActual = posHabita;
						panel.getListaHabitaciones().setSelectedIndex(posHabita);
					} catch (miExcepcion exc) {
						errorHabitaNoEncontrada();
					}
					apagar();
					break;
				}
			}
			break;

		case "encender":
			if (enEscucha) {
				int indexDisp = encontrarDispositivo(objeto);
				try {
					validarDisp(indexDisp);
					Dispositivo disp = casa.getListaPisos().get(pisoActual).getListHabitaciones().get(habiActual)
							.getDispositivos().get(indexDisp);
					if (!disp.isEncendido()) {
						disp.encender();
					} else {
						errorDispEncendido();
					}
				} catch (miExcepcion exc) {
					System.out.println(exc.getMessage());
					errorNoExisteDisp();
				}

			}
			apagar();
			break;

		case "apagar":
			System.out.println("apagar");
			if (enEscucha) {
				int indexDisp = encontrarDispositivo(objeto);
				try {
					validarDisp(indexDisp);
					Dispositivo disp = casa.getListaPisos().get(pisoActual).getListHabitaciones().get(habiActual)
							.getDispositivos().get(indexDisp);
					if (disp.isEncendido()) {
						disp.apagar();
					} else {
						errorDispEstaApagado();
					}
				} catch (miExcepcion exc) {
					System.out.println(exc.getMessage());
					errorNoExisteDisp();
				}

			}
			apagar();
		}
	}

	private void validarDisp(int i) throws miExcepcion {
		if (i == -1)
			throw new miExcepcion("No existe el dispositivo");
	}

	private void validarHabita(int i) throws miExcepcion {
		if (i == -1)
			throw new miExcepcion("No existe la habitacion");
	}

	private void errorNoExisteDisp() {
		enEscucha = false;
		r = new Lee("El dispositivo que has buscado no existe, vuelva a llamarme");
		new Thread(r).start();
	}

	private void errorDispEstaApagado() {
		enEscucha = false;
		r = new Lee("El dispositivo que has elegido ya esta apagado");
		new Thread(r).start();
	}

	private void errorDispEncendido() {
		enEscucha = false;
		r = new Lee("El dispositivo que has elegido ya esta encendido");
		new Thread(r).start();
	}

	private void errorPisoNoEncontrado() {
		enEscucha = false;
		r = new Lee("El piso que busca no se encuentra");
		new Thread(r).start();
	}

	private void errorHabitaNoEncontrada() {
		enEscucha = false;
		r = new Lee("La habitacion que busca no se encuentra");
		new Thread(r).start();
	}

	private String habitaAString() {
		return casa.getListaPisos().get(pisoActual).getListHabitaciones().get(habiActual).getNombre();
	}

	private int encontrarDispositivo(String disp) {
		int kont = 0;
		for (Dispositivo d : casa.getListaPisos().get(pisoActual).getListHabitaciones().get(habiActual)
				.getDispositivos()) {
			if (disp.toLowerCase().equals(d.getNombre().toLowerCase())) {
				return kont;
			}
			kont++;
		}
		return -1;
	}

}