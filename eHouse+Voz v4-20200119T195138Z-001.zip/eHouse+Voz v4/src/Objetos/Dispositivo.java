package Objetos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;

import javax.swing.Timer;

public class Dispositivo implements Serializable, ActionListener{

	private static final long serialVersionUID = 1L;
	String nombre;
	int id;
	double consumoPorSeg, consumoGenerado;
	boolean encendido;
	Timer timer;
	PropertyChangeSupport soporte;

	public Dispositivo(int id, String nombre, double consumoPorSeg) {
		this.id = id;
		this.nombre = nombre;
		this.consumoGenerado = 0;
		this.consumoPorSeg = consumoPorSeg;
		this.encendido = false;
		soporte = new PropertyChangeSupport(this);
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return id+" "+nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void consumir() {
		if (encendido) {
			double anterior=consumoGenerado;
			consumoGenerado += consumoPorSeg;
			double nuevo=consumoGenerado;
			soporte.firePropertyChange("consumo", anterior,nuevo );
		}
	}
	
	public void addPropertyChangeListener(PropertyChangeListener listener) {
		soporte.addPropertyChangeListener(listener);
	}

	public void apagar() {
		encendido = false;
		timer.stop();
	}

	public void power() {
		if (encendido) {
			apagar();
		} else {
			encender();
		}
	}

	public void encender() {
		encendido = true;
		timer= new Timer(1000,this);
		timer.start();
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public double getConsumoPorSeg() {
		return consumoPorSeg;
	}

	public void setConsumoGenerado(double consumoGenerado) {
		this.consumoGenerado = consumoGenerado;
	}

	public Object getFieldAt(int columna) {
		switch (columna) {
		case 0:
			return id;
		case 1:
			return nombre;
		case 2:
			return consumoPorSeg;
		case 3:
			return encendido;
		case 4:
			return consumoGenerado;
		default:
			return null;
		}
	}

	public Class<?> getFieldClass(int indice) {
		switch (indice) {
		case 0:
			return Integer.class;
		case 1:
			return String.class;
		case 2:
			return Double.class;
		case 3:
			return Boolean.class;
		case 4:
			return Double.class;
		default:
			return String.class;
		}

	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (!(obj instanceof Dispositivo))
			return false;
		Dispositivo disp = (Dispositivo) obj;
		if (disp instanceof DispositivoProgramable | disp instanceof DispositivoRegulable)
			return false;
		if (!this.nombre.toLowerCase().equals(disp.getNombre().toLowerCase()))
			return false;
		return true;
	}

	public double getConsumoGenerado() {
		return consumoGenerado;
	}

	public int getId() {
		return id;
	}

	public boolean isEncendido() {
		return encendido;
	}

	public void setEncendido(boolean encendido) {
		this.encendido = encendido;
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		this.consumir();
		
	}

}
