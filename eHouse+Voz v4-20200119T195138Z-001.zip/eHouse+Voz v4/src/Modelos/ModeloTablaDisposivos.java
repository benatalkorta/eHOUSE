package Modelos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import Objetos.Dispositivo;

public class ModeloTablaDisposivos extends AbstractTableModel implements Serializable{

	private static final long serialVersionUID = 1L;
	List<Dispositivo> listaDispositivos;
	final static String[] NOMBRE_COLUMNAS = { "Id", "Nombre", "Consumo kW/s", "Estado", "Consumo generado" };
	final static Class<?>[] TIPO_COLUMNAS = new Class<?>[] { Integer.class, String.class, Double.class, Boolean.class, Double.class };

	public ModeloTablaDisposivos() {
		listaDispositivos = new ArrayList<>();
	}

	public void add(Dispositivo d) {
		listaDispositivos.add(d);
		this.fireTableDataChanged();
	}

	public void remove(Dispositivo d) {
		listaDispositivos.remove(d);
		this.fireTableDataChanged();
	}
	
	@Override
	public String getColumnName(int column) {
		return NOMBRE_COLUMNAS[column];
	}

	@Override
	public Class<?> getColumnClass(int column) {
		return TIPO_COLUMNAS[column];
	}
	
	@Override
	public void setValueAt(Object aValue, int fila, int columna) {
		Dispositivo d = listaDispositivos.get(fila);
		if (columna == 3)
			d.power();
	}

	@Override
	public boolean isCellEditable(int row, int col) {
		return col == 3;
	}

	@Override
	public int getColumnCount() {
		return NOMBRE_COLUMNAS.length;
	}

	@Override
	public int getRowCount() {
		return listaDispositivos.size();
	}

	@Override
	public Object getValueAt(int fila, int columna) {
		Dispositivo d = listaDispositivos.get(fila);
		return d.getFieldAt(columna);
	}

}
