package Controladores;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;

import Componentes.TablaDispositivos;
import Dialogos.DialogoAddDispositivo;
import Dialogos.DialogoAddHabitacion;
import Dialogos.DialogoAddPiso;
import Dialogos.DialogoCrearUsuario;
import Excepcciones.miExcepcion;
import Modelos.ModeloTablaDisposivos;
import Objetos.Casa;
import Objetos.Dispositivo;
import Objetos.DispositivoProgramable;
import Objetos.Habitacion;
import Objetos.Piso;
import Objetos.Programa;
import Objetos.Usuario;
import Paneles.PanelConfiguracion;
import Paneles.PanelDispositivo;

public class ControladorConfiguracion
		implements ActionListener, ItemListener, ListSelectionListener, PropertyChangeListener {
	Casa casa;
	PanelConfiguracion panelConfiguracion;

	public ControladorConfiguracion(PanelConfiguracion panelConfiguracion) {
		this.panelConfiguracion = panelConfiguracion;
		casa = panelConfiguracion.getVentana().getCasa();
		anclarDispositivosConTabla();
	}

	public void anclarDispositivosConTabla() {
		for (Piso p : casa.getListaPisos()) {
			for (Habitacion h : p.getListHabitaciones()) {
				for (Dispositivo d : h.getDispositivos()) {
					d.addPropertyChangeListener(this);
					if (d instanceof DispositivoProgramable) {
						DispositivoProgramable dProg = (DispositivoProgramable) d;
						for (Programa prog : dProg.getListaProgramas()) {
							prog.addPropertyChangeListener(dProg);
						}
					}
				}
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {

		case "add_piso":
			DialogoAddPiso dialogoPiso = new DialogoAddPiso(panelConfiguracion.getVentana());
			Piso piso = dialogoPiso.getPiso();
			if (piso != null) {
				if (!casa.contienePiso(piso)) {
					piso.addHabitacion(new Habitacion("Habitacion principal"));
					casa.addPiso(piso);
					panelConfiguracion.getCbxpisos().setModel(casa.getComboBoxModelo());
					casa.guardarCasaEnFichero();
				} else {
					JOptionPane.showMessageDialog(panelConfiguracion, "El piso que has introducido ya existe",
							"WARNING!!", JOptionPane.WARNING_MESSAGE);
				}
			}

			break;

		case "remove_piso":
			int indexPiso = panelConfiguracion.getCbxpisos().getSelectedIndex();
			try {
				validar(indexPiso);
				int numPisos = casa.getListaPisos().size();
				validarBorrado(numPisos, "un piso");
				int numPiso = casa.getListaPisos().get(indexPiso).getNum();
				casa.removePisoAt(indexPiso);
				casa.reordenar(numPiso, numPisos);
				panelConfiguracion.getCbxpisos().setModel(casa.getComboBoxModelo());
				Piso p = casa.getListaPisos().get(0);
				panelConfiguracion.getListaHabitaciones()
						.setListData(p.getListHabitaciones().toArray(new Habitacion[0]));
				panelConfiguracion.getListaHabitaciones().setSelectedIndex(0);
				casa.guardarCasaEnFichero();
			} catch (miExcepcion exc) {
				System.out.println(exc.getMessage());
				JOptionPane.showMessageDialog(panelConfiguracion, exc.getMessage(), "WARNING!!",
						JOptionPane.WARNING_MESSAGE);

			}

			break;

		case "add_habitacion":
			int i = panelConfiguracion.getCbxpisos().getSelectedIndex();
			Piso p = casa.getElementAt(i);
			DialogoAddHabitacion dialogoHabitacion = new DialogoAddHabitacion(panelConfiguracion.getVentana());
			Habitacion habitacion = dialogoHabitacion.getHabitacion();
			if (habitacion != null) {
				if (!p.contieneHabitacion(habitacion)) {
					p.addHabitacion(habitacion);
					casa.guardarCasaEnFichero();
				} else {
					JOptionPane.showMessageDialog(panelConfiguracion, "La habitacion que has introducido ya existe",
							"WARNING!!", JOptionPane.WARNING_MESSAGE);
				}

			}

			break;

		case "remove_habitacion":
			int indexHabita = panelConfiguracion.getListaHabitaciones().getSelectedIndex();
			int indexPisoR = panelConfiguracion.getCbxpisos().getSelectedIndex();
			try {
				validar(indexHabita);
				int numHabitas = casa.getListaPisos().get(indexPisoR).getListHabitaciones().size();
				validarBorrado(numHabitas, "una habitacion");
				Piso pisoHabita = casa.getElementAt(indexPisoR);
				Habitacion h = pisoHabita.getElementAt(indexHabita);
				pisoHabita.removeHabitacion(h);
				panelConfiguracion.getListaHabitaciones()
						.setListData(pisoHabita.getListHabitaciones().toArray(new Habitacion[0]));
				panelConfiguracion.getListaHabitaciones().setSelectedIndex(0);
				casa.guardarCasaEnFichero();
			} catch (miExcepcion exc) {
				System.out.println(exc.getMessage());
				JOptionPane.showMessageDialog(panelConfiguracion, exc.getMessage(), "WARNING!!",
						JOptionPane.WARNING_MESSAGE);
			}

			break;

		case "crear_usuario":
			DialogoCrearUsuario dialogoCrearUsuario = new DialogoCrearUsuario(panelConfiguracion.getVentana());
			Usuario usuario = dialogoCrearUsuario.getUsuario();
			if (usuario != null) {
				try {
					panelConfiguracion.getVentana().getGestorUsuarios().existeNombre(usuario);
					panelConfiguracion.getVentana().getGestorUsuarios().a�adir(usuario);
					panelConfiguracion.getVentana().getGestorUsuarios().escribirUsuariosEnFichero();
					int opcion = JOptionPane.showConfirmDialog(panelConfiguracion.getVentana(),
							"�Desea iniciar sesi�n con este nuevo usuario?", "", JOptionPane.YES_NO_OPTION,
							JOptionPane.QUESTION_MESSAGE);
					if (opcion == JOptionPane.YES_OPTION) {
						panelConfiguracion.cambiarUsuario(usuario);
					}
				} catch (miExcepcion exc) {
					JOptionPane.showMessageDialog(dialogoCrearUsuario, exc.getMessage(), "ERROR!!",
							JOptionPane.ERROR_MESSAGE);
				}

			}
			break;

		case "remove_dispositivo":
			TablaDispositivos tablaDisp = panelConfiguracion.getTablaDispositivos();
			Habitacion habita = panelConfiguracion.getListaHabitaciones().getSelectedValue();
			int indexDisp = tablaDisp.getSelectedRow();
			try {
				validar(indexDisp);
				int numDispositivos = habita.getDispositivos().size();
				Dispositivo dispositivo = habita.getDispositivos()
						.get(tablaDisp.convertRowIndexToModel(tablaDisp.getSelectedRow()));
				int numDispositivo = dispositivo.getId();
				if (dispositivo != null) {
					habita.removeDispositivo(dispositivo);
					habita.reordenar(numDispositivo, numDispositivos);
					casa.guardarCasaEnFichero();
				}
			} catch (miExcepcion exc) {
				System.out.println(exc.getMessage());
				JOptionPane.showMessageDialog(panelConfiguracion, exc.getMessage(), "WARNING!!",
						JOptionPane.WARNING_MESSAGE);
			}

			break;

		case "add_dispositivo":
			Habitacion habitacionActual = panelConfiguracion.getListaHabitaciones().getSelectedValue();
			DialogoAddDispositivo digalogoAddDisp = new DialogoAddDispositivo(habitacionActual,
					panelConfiguracion.getVentana());
			Dispositivo dispositivo = digalogoAddDisp.getDispositivo();
			if (dispositivo != null) {
				if (!habitacionActual.contieneDispositivo(dispositivo)) {
					dispositivo.addPropertyChangeListener(this);
					habitacionActual.addDispositivo(dispositivo);
					casa.guardarCasaEnFichero();
				} else {
					JOptionPane.showMessageDialog(panelConfiguracion, "El dispositivo que has introducido ya existe",
							"WARNING!!", JOptionPane.WARNING_MESSAGE);
				}

			}

			break;

		default:
			panelConfiguracion.getVentana().entrarModoPrincipal();
			break;
		}

	}

	@Override
	public void itemStateChanged(ItemEvent evt) {
		if (evt.getSource() == panelConfiguracion.getCbxpisos()) {
			Piso p = casa.getElementAt(panelConfiguracion.getCbxpisos().getSelectedIndex());
			if (p != null) {
				panelConfiguracion.getListaHabitaciones().setModel(p);
				panelConfiguracion.getListaHabitaciones().setSelectedIndex(0);
				Habitacion habitacion = panelConfiguracion.getListaHabitaciones().getSelectedValue();
				if (habitacion != null) {
					panelConfiguracion.getTablaDispositivos().setModel(habitacion.getModeloTabla());
				} else {
					panelConfiguracion.getTablaDispositivos().setModel(new ModeloTablaDisposivos());
				}
				PanelDispositivo panelDispositivo = new PanelDispositivo(panelConfiguracion.getVentana(), null, false);
				panelConfiguracion.getSpanel().setBottomComponent(panelDispositivo);
				panelConfiguracion.getSpanel().setDividerLocation(300);
			}
		}
	}

	@Override
	public void valueChanged(ListSelectionEvent evt) {
		if (evt.getValueIsAdjusting())
			return;
		if (evt.getSource() == panelConfiguracion.getListaHabitaciones()) {
			Habitacion habitacion = panelConfiguracion.getListaHabitaciones().getSelectedValue();
			if (habitacion != null) {
				panelConfiguracion.getTablaDispositivos().setModel(habitacion.getModeloTabla());
				panelConfiguracion.getTablaDispositivos().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
				tcr.setHorizontalAlignment(SwingConstants.CENTER);
				panelConfiguracion.getTablaDispositivos().getColumnModel().getColumn(0).setCellRenderer(tcr);
				panelConfiguracion.getTablaDispositivos().getColumnModel().getColumn(1).setCellRenderer(tcr);
				panelConfiguracion.getTablaDispositivos().getColumnModel().getColumn(2).setCellRenderer(tcr);
				panelConfiguracion.getTablaDispositivos().getColumnModel().getColumn(4).setCellRenderer(tcr);
			}
			PanelDispositivo panelDispositivo = new PanelDispositivo(panelConfiguracion.getVentana(), null, false);
			panelConfiguracion.getSpanel().setBottomComponent(panelDispositivo);
			panelConfiguracion.getSpanel().setDividerLocation(300);
		}

	}

	private void validarBorrado(int i, String s) throws miExcepcion {
		if (i == 1)
			throw new miExcepcion("Tiene que haber un minimo de " + s);
	}

	private void validar(int i) throws miExcepcion {
		if (i == -1)
			throw new miExcepcion("No se encuentra");
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		panelConfiguracion.repaint();

	}
}