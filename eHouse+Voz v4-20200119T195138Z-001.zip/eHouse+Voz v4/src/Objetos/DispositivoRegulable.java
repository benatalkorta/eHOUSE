package Objetos;

import java.io.Serializable;

public class DispositivoRegulable extends Dispositivo implements Serializable {

	private static final long serialVersionUID = 1L;

	final int MIN = 0;
	final int MAX = 100;
	int nivel;

	public DispositivoRegulable(int id, String nombre, double consumo) {
		super(id, nombre, consumo);
		nivel = 0;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public int getNivel() {
		return nivel;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (!(obj instanceof Dispositivo))
			return false;
		Dispositivo disp = (Dispositivo) obj;
		if (disp instanceof DispositivoProgramable)
			return false;
		if (disp instanceof DispositivoRegulable) {
			if (!this.nombre.toLowerCase().equals(disp.getNombre().toLowerCase())) {
				return false;
			} else {
				return true;
			}
		} else {
			return false;
		}
	}

	@Override
	public String toString() {
		return super.toString() + " || Nivel: " + nivel + "%";
	}

}
