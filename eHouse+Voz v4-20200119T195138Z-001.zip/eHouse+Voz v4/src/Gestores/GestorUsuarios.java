package Gestores;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import Excepcciones.miExcepcion;
import Objetos.Usuario;

public class GestorUsuarios {

	final static String NOMBRE_FICHERO = "usuarios.dat";
	List<Usuario> listaUsuarios;
	Usuario usuarioLogeado;

	public GestorUsuarios() {
		listaUsuarios = new ArrayList<>();
		usuarioLogeado = null;
	}

//	public void inicializar() {
//		a�adir(new Usuario("Alex", ""));
//	}

	public void a�adir(Usuario usuario) {
		listaUsuarios.add(usuario);
	}

	public void existeNombre(Usuario usuario) throws miExcepcion {
		for (Usuario u : listaUsuarios) {
			if (u.getNombre().equals(usuario.getNombre())) {
				throw new miExcepcion("El usuario ya existe");
			}
		}
	}

	public Usuario getUsuarioLogeado() {
		return usuarioLogeado;
	}

	public void setUsuarioLogeado(Usuario usuarioLogeado) {
		this.usuarioLogeado = usuarioLogeado;
	}

	public List<Usuario> getLista() {
		List<Usuario> copia = new ArrayList<Usuario>(listaUsuarios);
		Collections.copy(copia, listaUsuarios);
		return copia;
	}

	public boolean existeUsuario(Usuario u) {
		return listaUsuarios.contains(u);
	}

	public void leerUsuariosDesdeFichero() {
		Usuario usuario;
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("files/" + NOMBRE_FICHERO))) {

			while ((usuario = (Usuario) in.readObject()) != null) {
				a�adir(usuario);
			}
		} catch (IOException | ClassNotFoundException e) {

		}
	}

	public void escribirUsuariosEnFichero() {
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("files/" + NOMBRE_FICHERO))) {
			for (Usuario u : listaUsuarios) {
				out.writeObject(u);
			}
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
