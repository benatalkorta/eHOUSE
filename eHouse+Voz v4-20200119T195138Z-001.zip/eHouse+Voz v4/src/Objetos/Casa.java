package Objetos;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;

public class Casa implements Serializable {

	private static final long serialVersionUID = 1L;
	public final static String FICHERO_CASA = "casa.dat";
	List<Piso> listaPisos;
	Consumo consumo;

	public Casa() {
		listaPisos = new ArrayList<>();
		consumo = new Consumo();
	}

	public double consumoTotalMomentaneo() {
		double total = 0;
		for (Piso p : listaPisos) {
			for (Habitacion h : p.getListHabitaciones()) {
				for (Dispositivo d : h.getDispositivos()) {
					total += d.getConsumoGenerado();
				}
			}
		}
		return total;
	}

	public void reordenar(int numPiso, int numPisos) {
		if (numPiso != numPisos) {
			int id = numPiso;
			for (int i = numPiso; i < numPisos; i++) {
				listaPisos.get(i - 1).setNum(id);
				id++;
			}
		}
	}

	public boolean contienePiso(Piso p) {
		return listaPisos.contains(p);
	}

	public Piso getElementAt(int i) {
		return listaPisos.get(i);
	}

	public void addPiso(Piso p) {
		listaPisos.add(p);
	}

	public void removePiso(Piso p) {
		listaPisos.remove(p);
	}

	public void removePisoAt(int i) {
		listaPisos.remove(i);
	}

	public DefaultComboBoxModel<Piso> getComboBoxModelo() {
		Piso[] comboBoxModelo = listaPisos.toArray(new Piso[0]);
		return new DefaultComboBoxModel<>(comboBoxModelo);
	}

	public List<Piso> getListaPisos() {
		return listaPisos;
	}

	public void guardarCasaEnFichero() {
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("files/" + FICHERO_CASA))) {
			out.writeObject(this);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

//	public void inicializar() {
//		Habitacion h1 = new Habitacion("Cocina");
//		h1.addDispositivo(new Dispositivo(1, "Frigor�fico", 100.2));
//		DispositivoProgramable disProg = new DispositivoProgramable(2, "Microondas", 10.5);
//		disProg.addPrograma(new Programa(1, "modo rapido"));
//		h1.addDispositivo(disProg);
//		Habitacion h2 = new Habitacion("Dormitorio 1");
//		h2.addDispositivo(new DispositivoRegulable(1, "Lampara", 50));
//		h2.addDispositivo(new Dispositivo(2, "Calefacci�n", 125.6));
//		Piso piso1 = new Piso(1);
//		piso1.addHabitacion(h1);
//		piso1.addHabitacion(h2);
//		this.addPiso(piso1);
//
//		guardarCasaEnFichero();
//	}

	public Consumo getConsumo() {
		return consumo;
	}

}
