package Componentes;

import java.awt.Color;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

import Objetos.Habitacion;

public class TablaDispositivos extends JTable {

	private static final long serialVersionUID = 1L;

	public TablaDispositivos(Habitacion habitacion) {
		this.setModel(habitacion.getModeloTabla());
		this.setRowHeight(30);
		this.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
		tcr.setHorizontalAlignment(SwingConstants.CENTER);
		this.setBackground(Color.white);
		//tcr.setBackground(Color.white);
		this.getColumnModel().getColumn(0).setCellRenderer(tcr);
		this.getColumnModel().getColumn(1).setCellRenderer(tcr);
		this.getColumnModel().getColumn(2).setCellRenderer(tcr);
		this.getColumnModel().getColumn(4).setCellRenderer(tcr);
	}

}
