package Controladores;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;

import Modelos.ModeloTablaDisposivos;
import Objetos.Casa;
import Objetos.Dispositivo;
import Objetos.DispositivoProgramable;
import Objetos.Habitacion;
import Objetos.Piso;
import Objetos.Programa;
import Paneles.PanelDispositivo;
import Paneles.PanelNormal;

public class ControladorNormal implements ActionListener, ItemListener, ListSelectionListener, PropertyChangeListener {

	PanelNormal panelNormal;
	Casa casa;

	public ControladorNormal(PanelNormal panelNormal) {
		this.panelNormal = panelNormal;
		casa = panelNormal.getVentana().getCasa();
		anclarDispositivosConTabla();
	}

	public void anclarDispositivosConTabla() {
		for (Piso p : casa.getListaPisos()) {
			for (Habitacion h : p.getListHabitaciones()) {
				for (Dispositivo d : h.getDispositivos()) {
					d.addPropertyChangeListener(this);
					if (d instanceof DispositivoProgramable) {
						DispositivoProgramable dProg = (DispositivoProgramable) d;
						for (Programa prog : dProg.getListaProgramas()) {
							prog.addPropertyChangeListener(dProg);
						}
					}
				}
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {
		case "consumo":
			panelNormal.getVentana().visualizarPanelConsumo();
			break;

		case "dispositivos":
			panelNormal.getVentana().entrarModoNormal();
			break;

		case "salir":
			panelNormal.getVentana().entrarModoPrincipal();
			break;
		}

	}

	@Override
	public void itemStateChanged(ItemEvent evt) {
		if (evt.getSource() == panelNormal.getCbxpisos()) {
			Piso p = casa.getElementAt(panelNormal.getCbxpisos().getSelectedIndex());
			if (p != null) {
				panelNormal.getListaHabitaciones().setModel(p);
				panelNormal.getListaHabitaciones().setSelectedIndex(0);
				Habitacion habitacion = panelNormal.getListaHabitaciones().getSelectedValue();
				if (habitacion != null) {
					panelNormal.getTablaDispositivos().setModel(habitacion.getModeloTabla());
				}else {
					panelNormal.getTablaDispositivos().setModel(new ModeloTablaDisposivos());
				}
				
				PanelDispositivo panelDispositivo = new PanelDispositivo(panelNormal.getVentana(), null, false);
				panelNormal.getSpanel().setBottomComponent(panelDispositivo);
				panelNormal.getSpanel().setDividerLocation(300);
			}
		}
	}

	@Override
	public void valueChanged(ListSelectionEvent evt) {
		if (evt.getValueIsAdjusting())
			return;
		if (evt.getSource() == panelNormal.getListaHabitaciones()) {
			Habitacion habitacion = panelNormal.getListaHabitaciones().getSelectedValue();
			if (habitacion != null) {
				panelNormal.getTablaDispositivos().setModel(habitacion.getModeloTabla());
				panelNormal.getTablaDispositivos().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
				tcr.setHorizontalAlignment(SwingConstants.CENTER);
				panelNormal.getTablaDispositivos().getColumnModel().getColumn(0).setCellRenderer(tcr);
				panelNormal.getTablaDispositivos().getColumnModel().getColumn(1).setCellRenderer(tcr);
				panelNormal.getTablaDispositivos().getColumnModel().getColumn(2).setCellRenderer(tcr);
				panelNormal.getTablaDispositivos().getColumnModel().getColumn(4).setCellRenderer(tcr);
			}
			PanelDispositivo panelDispositivo = new PanelDispositivo(panelNormal.getVentana(), null, false);
			panelNormal.getSpanel().setBottomComponent(panelDispositivo);
			panelNormal.getSpanel().setDividerLocation(300);
		}

	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		panelNormal.repaint();
	}

}
